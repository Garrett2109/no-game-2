/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Letters extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("A", "./Letters/costumes/A.png", { x: 64, y: 64 }),
      new Costume("D", "./Letters/costumes/D.png", { x: 64, y: 64 }),
      new Costume("E", "./Letters/costumes/E.png", { x: 64, y: 64 }),
      new Costume("F", "./Letters/costumes/F.png", { x: 64, y: 64 }),
      new Costume("G", "./Letters/costumes/G.png", { x: 64, y: 64 }),
      new Costume("H", "./Letters/costumes/H.png", { x: 64, y: 64 }),
      new Costume("I", "./Letters/costumes/I.png", { x: 64, y: 64 }),
      new Costume("M", "./Letters/costumes/M.png", { x: 64, y: 64 }),
      new Costume("N", "./Letters/costumes/N.png", { x: 64, y: 64 }),
      new Costume("O", "./Letters/costumes/O.png", { x: 64, y: 64 }),
      new Costume("R", "./Letters/costumes/R.png", { x: 64, y: 64 }),
      new Costume("S", "./Letters/costumes/S.png", { x: 64, y: 64 }),
      new Costume("T", "./Letters/costumes/T.png", { x: 64, y: 64 }),
      new Costume("U", "./Letters/costumes/U.png", { x: 64, y: 64 }),
      new Costume("Z", "./Letters/costumes/Z.png", { x: 64, y: 64 }),
      new Costume("BIG", "./Letters/costumes/BIG.svg", {
        x: 243.99399399399397,
        y: 184.68468468468467,
      }),
    ];

    this.sounds = [
      new Sound("Drop", "./Letters/sounds/Drop.mp3"),
      new Sound("PickUp", "./Letters/sounds/PickUp.mp3"),
      new Sound("Place", "./Letters/sounds/Place.mp3"),
      new Sound("Metal", "./Letters/sounds/Metal.mp3"),
      new Sound("Wood", "./Letters/sounds/Wood.mp3"),
      new Sound("Smash", "./Letters/sounds/Smash.mp3"),
    ];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.CLONE_START, this.startAsClone),
      new Trigger(Trigger.CLICKED, this.whenthisspriteclicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "GAME START" },
        this.whenIReceiveGameStart
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Position Objects" },
        this.whenIReceivePositionObjects
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Impact" },
        this.whenIReceiveImpact
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "CLEAR EVERYTHING" },
        this.whenIReceiveClearEverything
      ),
      new Trigger(Trigger.BROADCAST, { name: "Setup" }, this.whenIReceiveSetup),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Spawn Letters" },
        this.whenIReceiveSpawnLetters
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Drop Visible Objects" },
        this.whenIReceiveDropVisibleObjects
      ),
    ];

    this.vars.instance = "BASE";
    this.vars.i = 4;
    this.vars.active = "TRUE";
    this.vars.yvel = -21;
    this.vars.xvel = -0.19076021223847292;
    this.vars.lastx = 220;
    this.vars.lasty = -165;
    this.vars.sparks = 0;
    this.vars.x = 171.7168419101463;
    this.vars.y = -170;
    this.vars.temporaryLetter = "TRUE";
    this.vars.placed = 0;
    this.vars.dist = 168.35973390332975;
    this.vars.bouncex = 0;
    this.vars.draggingSprite = "FALSE";
    this.vars.falling = "FALSE";
    this.vars.touchingMaze = 0;
    this.vars.holdOffsetx = 0;
    this.vars.holdOffsety = 0;
    this.vars.weightwarning = "FALSE";
  }

  *whenGreenFlagClicked() {
    this.stage.vars.Clonecount = 0;
    this.vars.instance = "BASE";
    this.moveAhead();
    this.visible = false;
  }

  *startAsClone() {
    this.vars.instance = "CLONE";
    this.stage.vars.Clonecount++;
    this.vars.temporaryLetter = "false";
    this.vars.x = this.x + this.toNumber(this.stage.vars.Scrollx);
    this.vars.y = this.y + this.toNumber(this.stage.vars.Scrolly);
    this.size = 40;
    this.moveAhead();
    if (this.toNumber(this.stage.vars.Scrollx) === 480) {
      this.visible = true;
      this.vars.temporaryLetter = "true";
      yield* this.jumpAndFall();
    } else {
      this.vars.active = "TRUE";
      this.vars.placed = 0;
      if (this.toNumber(this.stage.vars.Progress) === 0) {
        if (this.arrayIncludes(this.stage.vars.word, this.costume.name)) {
          this.vars.placed =
            this.indexInArray(this.stage.vars.word, this.costume.name) + 1;
        }
      } else {
        this.visible = true;
        this.vars.xvel = this.random(-4, 4);
        this.vars.yvel = this.random(2, 6);
        yield* this.dropLetter("TRUE", "TRUE");
        yield* this.checkDragAndDrop();
      }
    }
  }

  *dropLetter(sparks, impact) {
    this.vars.sparks = sparks;
    this.vars.bouncex = 0;
    this.vars.falling = "TRUE";
    this.vars.touchingMaze = "false";
    while (
      !(
        this.compare(this.y, -169) < 0 ||
        ((this.touching(this.sprites["Ground"].andClones()) ||
          this.toString(this.vars.touchingMaze) === "true") &&
          this.toString(this.vars.temporaryLetter) === "FALSE")
      )
    ) {
      this.vars.yvel--;
      this.vars.xvel = this.toNumber(this.vars.xvel) * 0.9;
      this.x += this.toNumber(this.vars.xvel);
      yield* this.checkTouchingMaze();
      if (this.toString(this.vars.touchingMaze) === "true") {
        this.x += 0 - this.toNumber(this.vars.xvel);
        this.vars.xvel = 0;
        this.vars.touchingMaze = "false";
      }
      yield* this.fallAndCheck();
      yield* this.checkTouchingMaze();
      this.vars.x = this.x + this.toNumber(this.stage.vars.Scrollx);
      this.vars.y = this.y + this.toNumber(this.stage.vars.Scrolly);
      yield;
    }
    if (this.toString(this.vars.temporaryLetter) === "FALSE") {
      if (this.compare(this.vars.yvel, 0) > 0) {
        this.vars.yvel = 0;
        yield* this.groundcheck(-1);
        yield* this.dropLetter(sparks, impact);
      } else {
        yield* this.groundcheck(1);
      }
    }
    this.vars.x = this.x + this.toNumber(this.stage.vars.Scrollx);
    this.vars.y = this.y + this.toNumber(this.stage.vars.Scrolly);
    if (this.compare(this.vars.yvel, -4) > 0) {
      this.vars.sparks = "FALSE";
    }
    this.vars.x = this.x + this.toNumber(this.stage.vars.Scrollx);
    this.vars.y = this.y + this.toNumber(this.stage.vars.Scrolly);
    this.vars.active = "TRUE";
    if (this.toString(this.vars.sparks) === "TRUE") {
      if (this.toString(impact) === "TRUE") {
        yield* this.startSound("Drop");
        this.broadcast("Impact");
      } else {
        if (this.toString(this.vars.temporaryLetter) === "TRUE") {
          yield* this.startSound("Smash");
        }
      }
      this.stage.vars.sparksx.push(this.x);
      this.stage.vars.sparksy.push(this.y);
      this.stage.vars.sparkstype.push("spark");
      this.vars.sparks = "FALSE";
    }
    if (this.touching(this.sprites["ButtonHitbox"].andClones())) {
      if (this.toString(this.vars.weightwarning) === "FALSE") {
        this.vars.weightwarning = "TRUE";
        this.stage.vars.Speech = 29;
        this.broadcast("Start Speaking");
      }
    }
    this.vars.falling = "FALSE";
  }

  *whenthisspriteclicked() {
    if (this.toString(this.vars.instance) === "CLONE") {
      if (this.toString(this.vars.active) === "TRUE") {
        yield* this.startSound("PickUp");
      }
    }
  }

  *wobble(fall) {
    this.size = 400;
    this.x += 2;
    this.y -= 2;
    this.size = 40;
    yield* this.wait(0.04);
    this.size = 400;
    this.x -= 6;
    this.size = 40;
    yield* this.wait(0.04);
    this.size = 400;
    this.x += 2;
    if (this.toString(fall) === "true") {
      this.y += 1;
      this.vars.y--;
    } else {
      this.y += 2;
    }
    this.size = 40;
    yield* this.wait(0.04);
    this.size = 400;
    this.goto(
      this.toNumber(this.vars.x) - this.toNumber(this.stage.vars.Scrollx),
      this.toNumber(this.vars.y) - this.toNumber(this.stage.vars.Scrolly)
    );
    this.size = 40;
  }

  *whenIReceiveGameStart() {
    if (this.toString(this.vars.instance) === "CLONE") {
      while (!(this.toString(this.vars.active) === "TRUE")) {
        yield;
      }
      yield* this.checkDragAndDrop();
    }
  }

  *dragAndDrop() {
    this.stage.vars.Dragging = "TRUE";
    this.vars.draggingSprite = "TRUE";
    this.vars.touchingMaze = "false";
    this.vars.holdOffsetx = this.x - this.mouse.x;
    this.vars.holdOffsety = this.y - this.mouse.y;
    while (
      !(
        !this.mouse.down ||
        this.toString(this.vars.touchingMaze) === "true" ||
        this.compare(Math.abs(this.mouse.x), 240) > 0 ||
        this.compare(Math.abs(this.mouse.y), 180) > 0
      )
    ) {
      this.vars.lastx = this.x;
      this.vars.lasty = this.y;
      this.goto(
        this.mouse.x + this.toNumber(this.vars.holdOffsetx),
        this.mouse.y + this.toNumber(this.vars.holdOffsety)
      );
      this.moveAhead();
      if (this.compare(Math.abs(this.x), 230) > 0) {
        this.x = (this.x / Math.abs(this.x)) * 230;
      }
      if (this.compare(Math.abs(this.y), 170) > 0) {
        this.y = (this.y / Math.abs(this.y)) * 170;
      }
      if (this.touching(this.sprites["Ground"].andClones())) {
        yield* this.groundcheck(1);
      }
      yield* this.checkTouchingMaze();
      yield;
    }
    this.vars.xvel = this.x - this.toNumber(this.vars.lastx);
    this.vars.yvel = this.y - this.toNumber(this.vars.lasty);
    if (this.toString(this.vars.touchingMaze) === "true") {
      yield* this.startSound("Drop");
      this.goto(this.toNumber(this.vars.lastx), this.toNumber(this.vars.lasty));
      this.vars.xvel = 0;
      this.vars.yvel = 0;
    }
    if (this.compare(Math.abs(this.toNumber(this.vars.xvel)), 10) > 0) {
      this.vars.xvel =
        (this.toNumber(this.vars.xvel) /
          Math.abs(this.toNumber(this.vars.xvel))) *
        10;
    }
    if (this.compare(Math.abs(this.toNumber(this.vars.yvel)), 10) > 0) {
      this.vars.yvel =
        (this.toNumber(this.vars.yvel) /
          Math.abs(this.toNumber(this.vars.yvel))) *
        10;
    }
    this.stage.vars.Dragging = "FALSE";
    this.vars.draggingSprite = "FALSE";
    if (this.compare(this.stage.vars.Progress, -1) > 0) {
      yield* this.checkForPlacement();
    }
    if (this.toNumber(this.vars.placed) === 0) {
      if (this.toString(this.stage.vars.Scrolling) === "true") {
        yield* this.sideCheck();
        this.vars.x = this.x + this.toNumber(this.stage.vars.Scrollx);
        this.vars.y = this.y + this.toNumber(this.stage.vars.Scrolly);
        while (!(this.toString(this.stage.vars.Scrolling) === "FALSE")) {
          yield;
        }
      }
      yield* this.dropLetter("TRUE", "TRUE");
    } else {
      this.vars.x = this.x + this.toNumber(this.stage.vars.Scrollx);
      this.vars.y = this.y + this.toNumber(this.stage.vars.Scrolly);
    }
  }

  *position() {
    if (this.toString(this.vars.draggingSprite) === "TRUE") {
      this.vars.x = this.x + this.toNumber(this.stage.vars.Scrollx);
      this.vars.y = this.y + this.toNumber(this.stage.vars.Scrolly);
    } else {
      this.size = 400;
      this.goto(
        this.toNumber(this.vars.x) - this.toNumber(this.stage.vars.Scrollx),
        this.toNumber(this.vars.y) - this.toNumber(this.stage.vars.Scrolly)
      );
      this.size = 40;
      this.visible = true;
    }
  }

  *whenIReceivePositionObjects() {
    if (this.toString(this.vars.instance) === "CLONE") {
      yield* this.position();
    }
  }

  *fallAndCheck() {
    if (this.touching("edge")) {
      this.x += 0 - this.toNumber(this.vars.xvel);
    }
    this.y += this.toNumber(this.vars.yvel);
    if (this.compare(this.y, -170) < 0) {
      this.y = -170;
    }
  }

  *whenIReceiveImpact() {
    if (this.toString(this.vars.falling) === "FALSE") {
      yield* this.wobble("FALSE");
    }
  }

  *checkForPlacement() {
    if (this.compare(this.vars.placed, 0) > 0) {
      this.stage.vars.word.splice(this.vars.placed - 1, 1, "");
      this.vars.placed = 0;
    }
    if (
      this.toNumber(this.stage.vars.Scrollx) === 0 &&
      this.toNumber(this.stage.vars.Scrolly) === 0
    ) {
      this.vars.i = 0;
      for (let i = 0; i < 4; i++) {
        this.vars.i++;
        if (
          this.toNumber(this.itemOf(this.stage.vars.word, this.vars.i - 1)) ===
          0
        ) {
          this.vars.dist = Math.sqrt(
            Math.abs(
              (this.x -
                this.toNumber(
                  this.itemOf(this.stage.vars.wordx, this.vars.i - 1)
                )) *
                (this.x -
                  this.toNumber(
                    this.itemOf(this.stage.vars.wordx, this.vars.i - 1)
                  ))
            ) +
              Math.abs(
                (this.y -
                  this.toNumber(
                    this.itemOf(this.stage.vars.wordy, this.vars.i - 1)
                  )) *
                  (this.y -
                    this.toNumber(
                      this.itemOf(this.stage.vars.wordy, this.vars.i - 1)
                    ))
              )
          );
          if (this.compare(this.vars.dist, 16) < 0) {
            yield* this.startSound("Place");
            this.vars.placed = this.vars.i;
            this.stage.vars.word.splice(this.vars.i - 1, 1, this.costume.name);
            this.goto(
              this.toNumber(
                this.itemOf(this.stage.vars.wordx, this.vars.i - 1)
              ),
              this.toNumber(this.itemOf(this.stage.vars.wordy, this.vars.i - 1))
            );
            this.broadcast("Check Word");
            return;
          }
        }
        yield;
      }
    }
  }

  *groundcheck(dir) {
    if (
      this.touching(this.sprites["Ground"].andClones()) ||
      this.touching(this.sprites["Maze"].andClones())
    ) {
      while (
        !(
          !(
            this.touching(this.sprites["Ground"].andClones()) ||
            this.touching(this.sprites["Maze"].andClones())
          ) || this.touching("edge")
        )
      ) {
        this.y += 1 * this.toNumber(dir);
      }
      if (this.touching(this.sprites["Maze"].andClones())) {
        this.warp(this.position)();
      }
    }
  }

  *whenIReceiveClearEverything() {
    /* TODO: Implement stop other scripts in sprite */ null;
    if (this.toString(this.vars.instance) === "CLONE") {
      this.stage.vars.Clonecount--;
      this.deleteThisClone();
    }
  }

  *jumpAndFall() {
    if (
      this.toNumber(this.vars.placed) === 0 &&
      ((this.compare(
        this.vars.x,
        this.x + this.toNumber(this.stage.vars.Scrollx)
      ) === 0 &&
        this.compare(
          this.vars.y,
          this.y + this.toNumber(this.stage.vars.Scrolly)
        ) === 0) ||
        this.toString(this.vars.active) === "FALSE")
    ) {
      this.vars.xvel = this.random(-4, 4);
      this.vars.yvel = this.random(2, 6);
      if (this.compare(this.y, -169) < 0) {
        this.y += this.toNumber(this.vars.yvel);
      }
      yield* this.dropLetter("FALSE", "FALSE");
      if (this.toString(this.vars.temporaryLetter) === "TRUE") {
        this.stage.vars.Clonecount--;
        this.deleteThisClone();
      }
    }
  }

  *whenIReceiveSetup() {
    if (this.toString(this.vars.instance) === "BASE") {
      this.stage.vars.Dragging = "FALSE";
      this.vars.draggingSprite = "FALSE";
      this.vars.falling = "FALSE";
      this.vars.weightwarning = "FALSE";
      this.effects.clear();
      this.visible = false;
      this.stage.vars.letterx = [];
      this.stage.vars.lettery = [];
      this.stage.vars.lettertype = [];
      this.stage.vars.word = [];
      this.stage.vars.word.push("G");
      this.stage.vars.word.push("A");
      this.stage.vars.word.push("M");
      this.stage.vars.word.push("E");
      yield* this.initLetters();
      yield* this.createLetterAt("R", 186, -170);
      yield* this.createLetterAt("F", 172, -170);
      yield* this.createLetterAt("O", 95, -170);
      yield* this.spawnLetters();
    }
  }

  *whenIReceiveSpawnLetters() {
    if (this.toString(this.vars.instance) === "BASE") {
      yield* this.spawnLetters();
    }
  }

  *spawnLetters() {
    while (!(this.stage.vars.lettertype.length === 0)) {
      this.costume = this.itemOf(this.stage.vars.lettertype, 0);
      this.goto(
        this.toNumber(this.itemOf(this.stage.vars.letterx, 0)),
        this.toNumber(this.itemOf(this.stage.vars.lettery, 0))
      );
      this.createClone();
      this.stage.vars.lettertype.splice(0, 1);
      this.stage.vars.letterx.splice(0, 1);
      this.stage.vars.lettery.splice(0, 1);
    }
  }

  *initLetters() {
    this.vars.i = 0;
    for (let i = 0; i < this.stage.vars.word.length; i++) {
      this.vars.i++;
      this.goto(
        this.toNumber(this.itemOf(this.stage.vars.wordx, this.vars.i - 1)),
        this.toNumber(this.itemOf(this.stage.vars.wordy, this.vars.i - 1))
      );
      this.costume = this.itemOf(this.stage.vars.word, this.vars.i - 1);
      this.createClone();
    }
  }

  *createLetterAt(type, x, y) {
    this.stage.vars.lettertype.push(type);
    this.stage.vars.letterx.push(x);
    this.stage.vars.lettery.push(y);
  }

  *checkDragAndDrop() {
    while (true) {
      while (
        !(
          this.mouse.down &&
          this.touching("mouse") &&
          this.toString(this.stage.vars.Dragging) === "FALSE" &&
          this.toString(this.stage.vars.Showingsettings) === "FALSE" &&
          this.toString(this.stage.vars.Clickguard) === "FALSE"
        )
      ) {
        yield;
      }
      yield* this.dragAndDrop();
      yield;
    }
  }

  *sideCheck() {
    if (this.touching(this.sprites["Maze"].andClones())) {
      while (!!this.touching(this.sprites["Maze"].andClones())) {
        this.x += 1;
      }
    }
  }

  *checkTouchingMaze() {
    if (this.touching(this.sprites["Maze"].andClones())) {
      this.vars.touchingMaze = "true";
    }
  }

  *whenIReceiveDropVisibleObjects() {
    if (this.toString(this.vars.instance) === "CLONE") {
      if (this.toNumber(this.vars.placed) === 0) {
        if (this.toString(this.vars.draggingSprite) === "FALSE") {
          if (
            this.compare(
              Math.abs(
                this.toNumber(this.vars.x) -
                  this.toNumber(this.stage.vars.Scrollx)
              ),
              240
            ) < 0 &&
            this.compare(
              Math.abs(
                this.toNumber(this.vars.y) -
                  this.toNumber(this.stage.vars.Scrolly)
              ),
              180
            ) < 0
          ) {
            yield* this.dropLetter("TRUE", "TRUE");
          }
        }
      }
    }
  }
}
