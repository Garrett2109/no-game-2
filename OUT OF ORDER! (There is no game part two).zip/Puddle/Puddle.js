/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Puddle extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Water", "./Puddle/costumes/Water.png", { x: 480, y: 36 }),
    ];

    this.sounds = [];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.BROADCAST, { name: "Flood" }, this.whenIReceiveFlood),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Fade In Game" },
        this.whenIReceiveFadeInGame
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Position Objects" },
        this.whenIReceivePositionObjects
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Impact" },
        this.whenIReceiveImpact
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "CLEAR EVERYTHING" },
        this.whenIReceiveClearEverything
      ),
    ];

    this.vars.x = 480;
    this.vars.y = -120;
  }

  *whenGreenFlagClicked() {
    this.goto(0, -140);
    this.moveBehind();
    this.visible = false;
  }

  *whenIReceiveFlood() {
    for (let i = 0; i < 38; i++) {
      this.vars.y++;
      yield* this.position();
      yield* this.wait(0.05);
      yield;
    }
    while (!(this.compare(this.stage.vars.Progress, 10) > 0)) {
      yield;
    }
    for (let i = 0; i < 18; i++) {
      this.vars.y--;
      yield* this.position();
      yield* this.wait(0.05);
      yield;
    }
  }

  *whenIReceiveFadeInGame() {
    this.vars.x = 480;
    this.vars.y = -140;
    this.moveAhead();
    this.moveBehind(2);
  }

  *whenIReceivePositionObjects() {
    yield* this.position();
  }

  *position() {
    this.goto(
      this.toNumber(this.vars.x) - this.toNumber(this.stage.vars.Scrollx),
      this.toNumber(this.vars.y) - this.toNumber(this.stage.vars.Scrolly)
    );
    if (
      this.compare(
        this.x,
        this.toNumber(this.vars.x) - this.toNumber(this.stage.vars.Scrollx)
      ) === 0 &&
      this.compare(
        this.y,
        this.toNumber(this.vars.y) - this.toNumber(this.stage.vars.Scrolly)
      ) === 0
    ) {
      this.visible = true;
    } else {
      this.visible = false;
    }
  }

  *whenIReceiveImpact() {
    yield* this.wobble();
  }

  *wobble() {
    this.x += 2;
    this.y -= 2;
    yield* this.wait(0.04);
    this.x -= 6;
    yield* this.wait(0.04);
    this.x += 2;
    this.y += 2;
    yield* this.wait(0.04);
    this.goto(
      this.toNumber(this.vars.x) - this.toNumber(this.stage.vars.Scrollx),
      this.toNumber(this.vars.y) - this.toNumber(this.stage.vars.Scrolly)
    );
  }

  *whenIReceiveClearEverything() {
    /* TODO: Implement stop other scripts in sprite */ null;
    this.visible = false;
  }
}
