/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Goat extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("FreeGoat1", "./Goat/costumes/FreeGoat1.png", {
        x: 88,
        y: 116,
      }),
      new Costume("FreeGoat2", "./Goat/costumes/FreeGoat2.png", {
        x: 88,
        y: 116,
      }),
      new Costume("FreeGoat3", "./Goat/costumes/FreeGoat3.png", {
        x: 88,
        y: 116,
      }),
    ];

    this.sounds = [];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "GAME START" },
        this.whenIReceiveGameStart
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "CLEAR EVERYTHING" },
        this.whenIReceiveClearEverything
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Impact" },
        this.whenIReceiveImpact
      ),
    ];

    this.vars.x = 960;
    this.vars.y = -87;
    this.vars.sparks = "TRUE";
    this.vars.falling = "FALSE";
    this.vars.yvel = -10;
    this.vars.xvel = 0;
  }

  *whenGreenFlagClicked() {
    this.size = 50;
    this.costume = "FreeGoat1";
    this.moveAhead();
    this.visible = false;
  }

  *whenIReceiveGameStart() {}

  *dropGoat(sparks) {
    this.vars.sparks = sparks;
    this.vars.falling = "TRUE";
    while (!this.touching(this.sprites["Ground"].andClones())) {
      this.vars.yvel--;
      this.vars.xvel = 0;
      this.x += this.toNumber(this.vars.xvel);
      this.y += this.toNumber(this.vars.yvel);
      yield;
    }
    yield* this.groundcheck();
    this.vars.x = this.x + this.toNumber(this.stage.vars.Scrollx);
    this.vars.y = this.y + this.toNumber(this.stage.vars.Scrolly);
    this.vars.falling = "FALSE";
    yield* this.startSound("Drop");
    this.broadcast("Impact");
  }

  *groundcheck() {
    if (this.touching(this.sprites["Ground"].andClones())) {
      while (!!this.touching(this.sprites["Ground"].andClones())) {
        this.y += 1;
      }
    }
  }

  *whenIReceiveClearEverything() {
    /* TODO: Implement stop other scripts in sprite */ null;
    this.visible = false;
  }

  *whenIReceiveImpact() {
    if (this.compare(this.stage.vars.Progress, 16) > 0) {
      yield* this.wobble();
    }
  }

  *wobble() {
    this.x += 2;
    this.y -= 2;
    yield* this.wait(0.04);
    this.x -= 6;
    yield* this.wait(0.04);
    this.x += 2;
    this.y += 2;
    yield* this.wait(0.04);
    this.goto(
      this.toNumber(this.vars.x) - this.toNumber(this.stage.vars.Scrollx),
      this.toNumber(this.vars.y) - this.toNumber(this.stage.vars.Scrolly)
    );
  }
}
