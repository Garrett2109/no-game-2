/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Water extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Water1", "./Water/costumes/Water1.png", { x: 24, y: 32 }),
      new Costume("Water2", "./Water/costumes/Water2.png", { x: 24, y: 32 }),
      new Costume("Water3", "./Water/costumes/Water3.png", { x: 24, y: 32 }),
      new Costume("Water4", "./Water/costumes/Water4.png", { x: 24, y: 32 }),
      new Costume("Water5", "./Water/costumes/Water5.png", { x: 24, y: 32 }),
      new Costume("Water6", "./Water/costumes/Water6.png", { x: 24, y: 32 }),
      new Costume("Water7", "./Water/costumes/Water7.png", { x: 24, y: 32 }),
      new Costume("Water8", "./Water/costumes/Water8.png", { x: 24, y: 32 }),
    ];

    this.sounds = [];

    this.triggers = [
      new Trigger(
        Trigger.BROADCAST,
        { name: "Impact" },
        this.whenIReceiveImpact
      ),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Position Objects" },
        this.whenIReceivePositionObjects
      ),
      new Trigger(Trigger.BROADCAST, { name: "Setup" }, this.whenIReceiveSetup),
      new Trigger(Trigger.CLONE_START, this.startAsClone),
      new Trigger(
        Trigger.BROADCAST,
        { name: "CLEAR EVERYTHING" },
        this.whenIReceiveClearEverything
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Water_Off" },
        this.whenIReceiveWaterOff
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Water_On" },
        this.whenIReceiveWaterOn
      ),
    ];

    this.vars.x = 608;
    this.vars.y = 196;
    this.vars.instance = "BASE";
    this.vars.targetY = 164;
  }

  *wobble() {
    this.x += 2;
    this.y -= 2;
    yield* this.wait(0.04);
    this.x -= 6;
    yield* this.wait(0.04);
    this.x += 2;
    this.y += 2;
    yield* this.wait(0.04);
    this.goto(
      this.toNumber(this.vars.x) - this.toNumber(this.stage.vars.Scrollx),
      this.toNumber(this.vars.y) - this.toNumber(this.stage.vars.Scrolly)
    );
  }

  *whenIReceiveImpact() {
    yield* this.wobble();
  }

  *whenGreenFlagClicked() {
    this.vars.instance = "BASE";
    this.moveAhead();
    this.visible = false;
  }

  *whenIReceivePositionObjects() {
    if (this.toString(this.vars.instance) === "CLONE") {
      yield* this.position();
    }
  }

  *position() {
    this.goto(
      this.toNumber(this.vars.x) - this.toNumber(this.stage.vars.Scrollx),
      this.toNumber(this.vars.y) - this.toNumber(this.stage.vars.Scrolly)
    );
    if (
      this.compare(
        this.x,
        this.toNumber(this.vars.x) - this.toNumber(this.stage.vars.Scrollx)
      ) === 0 &&
      this.compare(
        this.y,
        this.toNumber(this.vars.y) - this.toNumber(this.stage.vars.Scrolly)
      ) === 0
    ) {
      this.visible = true;
    } else {
      this.visible = false;
    }
  }

  *whenIReceiveSetup() {
    if (this.toString(this.vars.instance) === "BASE") {
      this.stage.vars.WaterComplete = "FALSE";
    }
  }

  *createClones() {
    this.vars.x = 608;
    this.vars.y = 196;
    this.vars.targetY = -124;
    for (let i = 0; i < 9; i++) {
      this.vars.targetY = this.toNumber(this.vars.targetY) + 32;
      this.createClone();
    }
  }

  *startAsClone() {
    this.vars.instance = "CLONE";
    this.stage.vars.Clonecount++;
    this.costume = "Water1";
    yield* this.position();
    while (true) {
      yield* this.wait(0);
      if (this.compare(this.vars.y, this.vars.targetY) > 0) {
        this.vars.y -= 4;
        yield* this.position();
      } else {
        null;
      }
      this.costumeNumber++;
      if (this.toNumber(this.vars.y) === -92) {
        this.stage.vars.WaterComplete = "true";
        if (this.toNumber(this.stage.vars.Progress) === 9) {
          this.stage.vars.Progress = 10;
          this.broadcast("Flood");
        }
      }
      yield;
    }
  }

  *whenIReceiveClearEverything() {
    /* TODO: Implement stop other scripts in sprite */ null;
    if (this.toString(this.vars.instance) === "CLONE") {
      this.stage.vars.Clonecount--;
      this.deleteThisClone();
    }
  }

  *whenIReceiveWaterOff() {
    if (this.toString(this.vars.instance) === "CLONE") {
      this.stage.vars.Clonecount--;
      this.deleteThisClone();
    }
  }

  *whenIReceiveWaterOn() {
    if (this.toString(this.vars.instance) === "BASE") {
      yield* this.createClones();
    }
  }
}
