/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Squirrel extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Squirrel1", "./Squirrel/costumes/Squirrel1.png", {
        x: 68,
        y: 68,
      }),
      new Costume("Squirrel2", "./Squirrel/costumes/Squirrel2.png", {
        x: 68,
        y: 68,
      }),
      new Costume("Squirrel3", "./Squirrel/costumes/Squirrel3.png", {
        x: 68,
        y: 68,
      }),
      new Costume("Squirrel4", "./Squirrel/costumes/Squirrel4.png", {
        x: 68,
        y: 68,
      }),
    ];

    this.sounds = [];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.BROADCAST, { name: "Setup" }, this.whenIReceiveSetup),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Position Objects" },
        this.whenIReceivePositionObjects
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Impact" },
        this.whenIReceiveImpact
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "GAME START" },
        this.whenIReceiveGameStart
      ),
      new Trigger(Trigger.CLICKED, this.whenthisspriteclicked),
    ];

    this.vars.x = 300;
    this.vars.y = -410;
  }

  *whenGreenFlagClicked() {
    this.size = 50;
    this.costume = "Squirrel1";
    this.visible = false;
  }

  *whenIReceiveSetup() {
    this.vars.x = 300;
    this.vars.y = -410;
    yield* this.position();
  }

  *whenIReceivePositionObjects() {
    yield* this.position();
  }

  *position() {
    this.goto(
      this.toNumber(this.vars.x) - this.toNumber(this.stage.vars.Scrollx),
      this.toNumber(this.vars.y) - this.toNumber(this.stage.vars.Scrolly)
    );
    if (
      this.compare(
        this.x,
        this.toNumber(this.vars.x) - this.toNumber(this.stage.vars.Scrollx)
      ) === 0 &&
      this.compare(
        this.y,
        this.toNumber(this.vars.y) - this.toNumber(this.stage.vars.Scrolly)
      ) === 0
    ) {
      this.visible = true;
    } else {
      this.visible = false;
    }
  }

  *whenIReceiveImpact() {
    yield* this.wobble();
  }

  *wobble() {
    this.x += 2;
    this.y -= 2;
    yield* this.wait(0.04);
    this.x -= 6;
    yield* this.wait(0.04);
    this.x += 2;
    this.y += 2;
    yield* this.wait(0.04);
    this.goto(
      this.toNumber(this.vars.x) - this.toNumber(this.stage.vars.Scrollx),
      this.toNumber(this.vars.y) - this.toNumber(this.stage.vars.Scrolly)
    );
  }

  *whenIReceiveGameStart() {
    while (true) {
      this.costumeNumber++;
      yield* this.wait(0.1);
      yield;
    }
  }

  *whenthisspriteclicked() {
    if (this.toNumber(this.stage.vars.Progress) === 18) {
      if (this.toString(this.stage.vars.Cuphint) === "FALSE") {
        this.stage.vars.Cuphint = "TRUE";
        this.broadcast("Cup Hint");
      }
    }
  }
}
