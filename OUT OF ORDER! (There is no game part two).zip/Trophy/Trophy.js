/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Trophy extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Trophy", "./Trophy/costumes/Trophy.png", { x: 84, y: 112 }),
      new Costume("Water", "./Trophy/costumes/Water.png", { x: 128, y: 128 }),
    ];

    this.sounds = [
      new Sound("Drop", "./Trophy/sounds/Drop.mp3"),
      new Sound("PickUp", "./Trophy/sounds/PickUp.mp3"),
      new Sound("Drop Water", "./Trophy/sounds/Drop Water.mp3"),
      new Sound("PickupWater", "./Trophy/sounds/PickupWater.mp3"),
    ];

    this.triggers = [
      new Trigger(
        Trigger.BROADCAST,
        { name: "Impact" },
        this.whenIReceiveImpact
      ),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.BROADCAST, { name: "Setup" }, this.whenIReceiveSetup),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Position Objects" },
        this.whenIReceivePositionObjects
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "GAME START" },
        this.whenIReceiveGameStart
      ),
      new Trigger(Trigger.CLICKED, this.whenthisspriteclicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "CLEAR EVERYTHING" },
        this.whenIReceiveClearEverything
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Drop Visible Objects" },
        this.whenIReceiveDropVisibleObjects
      ),
    ];

    this.vars.x = 415;
    this.vars.y = -454;
    this.vars.active = "true";
    this.vars.sparks = "FALSE";
    this.vars.yvel = -4;
    this.vars.xvel = 0;
    this.vars.draggingSprite = "FALSE";
    this.vars.lastx = 150;
    this.vars.lasty = -60;
    this.vars.falling = "FALSE";
    this.vars.touchingMaze = "false";
    this.vars.holdOffsetx = -5;
    this.vars.holdOffsety = -6;
    this.vars.weightwarning = "FALSE";
  }

  *wobble(x, y) {
    this.size = 400;
    this.x += this.toNumber(x);
    this.y += this.toNumber(y);
    this.size = 40;
    yield* this.wait(0.04);
  }

  *whenIReceiveImpact() {
    if (this.toString(this.vars.falling) === "FALSE") {
      yield* this.wobble(2, -2);
      yield* this.wobble(-6, 0);
      yield* this.wobble(2, 2);
      yield* this.resetwobble();
    }
  }

  *whenGreenFlagClicked() {
    this.size = 40;
    this.visible = false;
  }

  *whenIReceiveSetup() {
    this.costume = "Trophy";
    this.moveAhead();
    this.vars.active = "true";
    this.vars.falling = "FALSE";
    this.vars.draggingSprite = "FALSE";
    this.vars.weightwarning = "FALSE";
    this.vars.x = 415;
    this.vars.y = -454;
  }

  *whenIReceivePositionObjects() {
    if (this.toString(this.vars.active) === "true") {
      yield* this.position();
    }
  }

  *position() {
    if (this.toString(this.vars.draggingSprite) === "TRUE") {
      this.vars.x = this.x + this.toNumber(this.stage.vars.Scrollx);
      this.vars.y = this.y + this.toNumber(this.stage.vars.Scrolly);
    } else {
      this.size = 400;
      this.goto(
        this.toNumber(this.vars.x) - this.toNumber(this.stage.vars.Scrollx),
        this.toNumber(this.vars.y) - this.toNumber(this.stage.vars.Scrolly)
      );
      this.size = 40;
      this.visible = true;
    }
  }

  *whenIReceiveGameStart() {
    while (!(this.toString(this.vars.active) === "TRUE")) {
      yield;
    }
    while (true) {
      while (
        !(
          this.mouse.down &&
          this.touching("mouse") &&
          this.toString(this.stage.vars.Dragging) === "FALSE" &&
          this.toString(this.stage.vars.Clickguard) === "FALSE"
        )
      ) {
        yield;
      }
      yield* this.dragAndDrop();
      yield;
    }
  }

  *groundcheck(dir) {
    if (
      this.touching(this.sprites["Ground"].andClones()) ||
      this.touching(this.sprites["Maze"].andClones())
    ) {
      while (
        !(
          !(
            this.touching(this.sprites["Ground"].andClones()) ||
            this.touching(this.sprites["Maze"].andClones())
          ) || this.touching("edge")
        )
      ) {
        this.y += 1 * this.toNumber(dir);
      }
      if (this.touching(this.sprites["Maze"].andClones())) {
        this.warp(this.position)();
      }
    }
  }

  *dropTrophy(sparks) {
    this.vars.sparks = sparks;
    this.vars.falling = "TRUE";
    this.vars.touchingMaze = "false";
    while (
      !(
        this.compare(this.y, -157) < 0 ||
        this.touching(this.sprites["Ground"].andClones()) ||
        this.toString(this.vars.touchingMaze) === "true"
      )
    ) {
      this.vars.yvel--;
      this.vars.xvel = this.toNumber(this.vars.xvel) * 0.9;
      this.x += this.toNumber(this.vars.xvel);
      yield* this.checkTouchingMaze();
      if (this.toString(this.vars.touchingMaze) === "true") {
        this.x += 0 - this.toNumber(this.vars.xvel);
        this.vars.xvel = 0;
        this.vars.touchingMaze = "false";
      }
      yield* this.fallAndCheck();
      yield* this.checkTouchingMaze();
      this.vars.x = this.x + this.toNumber(this.stage.vars.Scrollx);
      this.vars.y = this.y + this.toNumber(this.stage.vars.Scrolly);
      yield;
    }
    if (this.compare(this.vars.yvel, 0) > 0) {
      this.vars.yvel = 0;
      yield* this.groundcheck(-1);
      yield* this.dropTrophy(sparks);
    } else {
      yield* this.groundcheck(1);
    }
    if (this.compare(this.vars.yvel, -8) > 0) {
      this.vars.sparks = "FALSE";
    }
    this.vars.x = this.x + this.toNumber(this.stage.vars.Scrollx);
    this.vars.y = this.y + this.toNumber(this.stage.vars.Scrolly);
    if (this.toString(this.vars.sparks) === "TRUE") {
      if (this.costume.name === "Water") {
        yield* this.startSound("Drop Water");
        yield* this.wait(0.1);
        this.costume = "Trophy";
        this.stage.vars.waterx.push(this.x);
        this.stage.vars.watery.push(this.y);
        if (this.touching(this.sprites["Pixelfire"].andClones())) {
          this.broadcast("End Fire");
        }
      } else {
        yield* this.startSound("Drop");
        this.stage.vars.sparksx.push(this.x);
        this.stage.vars.sparksy.push(this.y);
        this.stage.vars.sparkstype.push("spark");
        this.vars.sparks = "FALSE";
      }
      this.broadcast("Impact");
      if (this.touching(this.sprites["ButtonHitbox"].andClones())) {
        if (this.toString(this.vars.weightwarning) === "FALSE") {
          this.vars.weightwarning = "TRUE";
          this.stage.vars.Speech = 28;
          this.broadcast("Start Speaking");
        }
      }
    } else {
      if (this.touching(this.sprites["ButtonHitbox"].andClones())) {
        if (this.costume.name === "Water") {
          this.vars.xvel = 0;
          this.vars.yvel = 0;
          this.broadcast("Button Pressed");
        } else {
          if (this.toString(this.vars.weightwarning) === "FALSE") {
            this.vars.weightwarning = "TRUE";
            this.stage.vars.Speech = 28;
            this.broadcast("Start Speaking");
          }
        }
      }
    }
    this.vars.falling = "FALSE";
  }

  *fallAndCheck() {
    if (this.touching("edge")) {
      this.x += 0 - this.toNumber(this.vars.xvel);
    }
    this.y += this.toNumber(this.vars.yvel);
    if (this.compare(this.y, -158) < 0) {
      this.y = -158;
    }
  }

  *dragAndDrop() {
    this.stage.vars.Dragging = "TRUE";
    this.vars.draggingSprite = "TRUE";
    this.vars.touchingMaze = "false";
    this.vars.holdOffsetx = this.x - this.mouse.x;
    this.vars.holdOffsety = this.y - this.mouse.y;
    this.vars.lastx = this.x;
    this.vars.lasty = this.y;
    this.goto(
      this.mouse.x + this.toNumber(this.vars.holdOffsetx),
      this.mouse.y + this.toNumber(this.vars.holdOffsety)
    );
    this.moveAhead();
    yield* this.checkTouchingMaze();
    if (this.toString(this.vars.touchingMaze) === "true") {
      this.goto(this.toNumber(this.vars.lastx), this.toNumber(this.vars.lasty));
      this.vars.xvel = 0;
      this.vars.yvel = 0;
      this.vars.draggingSprite = "false";
      this.stage.vars.Dragging = "false";
    } else {
      while (
        !(!this.mouse.down || this.toString(this.vars.touchingMaze) === "true")
      ) {
        this.vars.lastx = this.x;
        this.vars.lasty = this.y;
        this.goto(
          this.mouse.x + this.toNumber(this.vars.holdOffsetx),
          this.mouse.y + this.toNumber(this.vars.holdOffsety)
        );
        this.moveAhead();
        if (this.compare(Math.abs(this.x), 215) > 0) {
          this.x = (this.x / Math.abs(this.x)) * 215;
        }
        if (this.compare(Math.abs(this.y), 158) > 0) {
          this.y = (this.y / Math.abs(this.y)) * 158;
        }
        if (
          this.touching(this.sprites["Water"].andClones()) &&
          this.costume.name === "Trophy" &&
          !(this.toString(this.stage.vars.Scrolling) === "TRUE")
        ) {
          yield* this.startSound("PickupWater");
          this.costume = "Water";
        }
        if (this.touching(this.sprites["Ground"].andClones())) {
          yield* this.groundcheck(1);
        }
        yield* this.checkTouchingMaze();
        yield;
      }
      this.vars.xvel = this.x - this.toNumber(this.vars.lastx);
      this.vars.yvel = this.y - this.toNumber(this.vars.lasty);
      if (this.toString(this.vars.touchingMaze) === "true") {
        yield* this.startSound("Drop");
        this.goto(
          this.toNumber(this.vars.lastx),
          this.toNumber(this.vars.lasty)
        );
        this.vars.xvel = 0;
        this.vars.yvel = 0;
      }
      if (this.compare(Math.abs(this.toNumber(this.vars.xvel)), 10) > 0) {
        this.vars.xvel =
          (this.toNumber(this.vars.xvel) /
            Math.abs(this.toNumber(this.vars.xvel))) *
          10;
      }
      if (this.compare(Math.abs(this.toNumber(this.vars.yvel)), 10) > 0) {
        this.vars.yvel =
          (this.toNumber(this.vars.yvel) /
            Math.abs(this.toNumber(this.vars.yvel))) *
          10;
      }
      this.stage.vars.Dragging = "FALSE";
      this.vars.draggingSprite = "FALSE";
      if (this.toString(this.stage.vars.Scrolling) === "true") {
        yield* this.sideCheck();
        this.vars.x = this.x + this.toNumber(this.stage.vars.Scrollx);
        this.vars.y = this.y + this.toNumber(this.stage.vars.Scrolly);
        while (!(this.toString(this.stage.vars.Scrolling) === "FALSE")) {
          yield;
        }
      }
    }
    yield* this.dropTrophy("TRUE");
  }

  *whenthisspriteclicked() {
    yield* this.startSound("PickUp");
    this.vars.active = "TRUE";
  }

  *whenIReceiveClearEverything() {
    /* TODO: Implement stop other scripts in sprite */ null;
    this.visible = false;
  }

  *checkTouchingMaze() {
    if (this.touching(this.sprites["Maze"].andClones())) {
      this.vars.touchingMaze = "true";
    }
  }

  *sideCheck() {
    if (this.touching(this.sprites["Maze"].andClones())) {
      while (!!this.touching(this.sprites["Maze"].andClones())) {
        this.x += 1;
      }
    }
  }

  *resetwobble() {
    this.size = 400;
    this.goto(
      this.toNumber(this.vars.x) - this.toNumber(this.stage.vars.Scrollx),
      this.toNumber(this.vars.y) - this.toNumber(this.stage.vars.Scrolly)
    );
    this.size = 40;
  }

  *whenIReceiveDropVisibleObjects() {
    if (this.toString(this.vars.active) === "TRUE") {
      if (this.toString(this.vars.draggingSprite) === "FALSE") {
        if (
          this.compare(
            Math.abs(
              this.toNumber(this.vars.x) -
                this.toNumber(this.stage.vars.Scrollx)
            ),
            240
          ) < 0 &&
          this.compare(
            Math.abs(
              this.toNumber(this.vars.y) -
                this.toNumber(this.stage.vars.Scrolly)
            ),
            180
          ) < 0
        ) {
          yield* this.dropTrophy("FALSE");
        }
      }
    }
  }
}
