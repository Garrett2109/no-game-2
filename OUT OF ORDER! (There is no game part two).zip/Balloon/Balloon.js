/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Balloon extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Balloon", "./Balloon/costumes/Balloon.svg", {
        x: 178,
        y: 472.9871868820034,
      }),
    ];

    this.sounds = [
      new Sound("GlitchExerpt", "./Balloon/sounds/GlitchExerpt.mp3"),
    ];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.BROADCAST, { name: "Setup" }, this.whenIReceiveSetup),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Impact" },
        this.whenIReceiveImpact
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Escape" },
        this.whenIReceiveEscape
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Sunset" },
        this.whenIReceiveSunset
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Position Objects" },
        this.whenIReceivePositionObjects
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "CLEAR EVERYTHING" },
        this.whenIReceiveClearEverything
      ),
      new Trigger(Trigger.BROADCAST, { name: "Bob" }, this.whenIReceiveBob),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Chimney" },
        this.whenIReceiveChimney
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Fade Tune" },
        this.whenIReceiveFadeTune
      ),
      new Trigger(Trigger.BROADCAST, { name: "Outro" }, this.whenIReceiveOutro),
    ];

    this.audioEffects.volume = 0;

    this.vars.x = 1440;
    this.vars.y = -360;
    this.vars.escaping = "false";
    this.vars.a = 294860;
    this.vars.dy = 0;
  }

  *whenGreenFlagClicked() {
    this.goto(0, 0);
    this.size = 100;
    this.visible = false;
  }

  *whenIReceiveSetup() {
    this.vars.escaping = "false";
    this.vars.x = 1440;
    this.vars.y = -360;
    this.moveAhead();
    yield* this.position();
  }

  *whenIReceiveImpact() {
    yield* this.wobble();
  }

  *wobble() {
    this.x += 2;
    this.y -= 2;
    yield* this.wait(0.04);
    this.x -= 6;
    yield* this.wait(0.04);
    this.x += 2;
    this.y += 2;
    yield* this.wait(0.04);
    this.goto(
      this.toNumber(this.vars.x) - this.toNumber(this.stage.vars.Scrollx),
      this.toNumber(this.vars.y) - this.toNumber(this.stage.vars.Scrolly)
    );
  }

  *position() {
    this.goto(
      this.toNumber(this.vars.x) - this.toNumber(this.stage.vars.Scrollx),
      this.toNumber(this.vars.y) - this.toNumber(this.stage.vars.Scrolly)
    );
    if (
      this.compare(
        this.x,
        this.toNumber(this.vars.x) - this.toNumber(this.stage.vars.Scrollx)
      ) === 0 &&
      this.compare(
        this.y,
        this.toNumber(this.vars.y) - this.toNumber(this.stage.vars.Scrolly)
      ) === 0
    ) {
      this.visible = true;
    } else {
      this.visible = false;
    }
  }

  *whenIReceiveEscape() {
    this.vars.escaping = "true";
    this.goto(0, 0);
    this.effects.clear();
    this.moveAhead();
    this.audioEffects.volume = 100;
    yield* this.startSound("GlitchExerpt");
    this.broadcast("Chimney");
    while (!(this.compare(this.size, 40) < 0)) {
      this.size -= 0.5;
      this.y -= 0.5;
      yield;
    }
  }

  *whenIReceiveSunset() {
    this.vars.dy = 5;
    while (!(this.toNumber(this.vars.dy) === 0)) {
      this.size -= 0.2;
      this.y += this.toNumber(this.vars.dy);
      this.vars.dy -= 0.25;
      yield;
    }
    for (let i = 0; i < 90; i++) {
      this.size -= 0.2;
      this.y -= 0.1;
      yield;
    }
    for (let i = 0; i < 200; i++) {
      this.size -= 0.2;
      this.effects.brightness -= 0.5;
      this.y -= 0.1;
      yield;
    }
  }

  *whenIReceivePositionObjects() {
    if (this.toString(this.vars.escaping) === "false") {
      yield* this.position();
    }
  }

  *whenIReceiveClearEverything() {
    this.visible = false;
  }

  *whenIReceiveBob() {
    this.vars.a = 0;
    this.size = 100;
    while (!(this.toString(this.vars.escaping) === "true")) {
      this.vars.a += 5;
      this.y = Math.sin(this.degToRad(this.toNumber(this.vars.a))) * 3;
      yield;
    }
  }

  *whenIReceiveChimney() {
    this.stage.vars.Scrolling = "true";
    while (!(this.toNumber(this.stage.vars.Scrolly) === 1416)) {
      this.vars.a += 5;
      this.x = Math.sin(this.degToRad(this.toNumber(this.vars.a))) * 3;
      this.stage.vars.Scrolly += 4;
      this.broadcast("Position Objects");
      yield;
    }
    this.stage.vars.Scrolling = "false";
    this.broadcast("Sunset");
  }

  *whenIReceiveFadeTune() {
    for (let i = 0; i < 200; i++) {
      this.audioEffects.volume -= 0.5;
      yield;
    }
  }

  *whenIReceiveOutro() {
    this.broadcast("Fade Tune");
  }
}
