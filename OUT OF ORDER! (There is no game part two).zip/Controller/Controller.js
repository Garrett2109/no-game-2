/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Controller extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Game", "./Controller/costumes/Game.svg", {
        x: 267.5165165165165,
        y: 201.4504504504504,
      }),
      new Costume("Title", "./Controller/costumes/Title.svg", {
        x: 240,
        y: 180,
      }),
      new Costume("PARTII", "./Controller/costumes/PARTII.svg", {
        x: 105,
        y: -136,
      }),
      new Costume("OutOfOrder", "./Controller/costumes/OutOfOrder.svg", {
        x: 240,
        y: 180,
      }),
      new Costume("Credits", "./Controller/costumes/Credits.svg", {
        x: 240,
        y: 180,
      }),
      new Costume("Untitled-4", "./Controller/costumes/Untitled-4.svg", {
        x: 200,
        y: 88,
      }),
      new Costume("costume1", "./Controller/costumes/costume1.svg", {
        x: 204.26729865776156,
        y: 114.2225908695651,
      }),
    ];

    this.sounds = [
      new Sound("Game Music", "./Controller/sounds/Game Music.mp3"),
      new Sound("Game Start", "./Controller/sounds/Game Start.mp3"),
      new Sound("Finish", "./Controller/sounds/Finish.mp3"),
      new Sound("End Music", "./Controller/sounds/End Music.mp3"),
      new Sound("Zip", "./Controller/sounds/Zip.mp3"),
      new Sound("Intro", "./Controller/sounds/Intro.mp3"),
      new Sound("Hum", "./Controller/sounds/Hum.mp3"),
      new Sound("Music", "./Controller/sounds/Music.mp3"),
      new Sound("Muffle", "./Controller/sounds/Muffle.mp3"),
      new Sound("BoxDrop", "./Controller/sounds/BoxDrop.mp3"),
    ];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Check Word" },
        this.whenIReceiveCheckWord
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "GAME START" },
        this.whenIReceiveGameStart
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Game Tune" },
        this.whenIReceiveGameTune
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Stop Sounds" },
        this.whenIReceiveStopSounds
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Room Sound" },
        this.whenIReceiveRoomSound
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Click Guard On" },
        this.whenIReceiveClickGuardOn
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Click Guard Off" },
        this.whenIReceiveClickGuardOff
      ),
      new Trigger(Trigger.BROADCAST, { name: "Hum" }, this.whenIReceiveHum),
      new Trigger(
        Trigger.BROADCAST,
        { name: "End Music" },
        this.whenIReceiveEndMusic
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "END OF GAME" },
        this.whenIReceiveEndOfGame
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "_THUMB" },
        this.whenIReceiveThumb
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "PRE_GAME" },
        this.whenIReceivePreGame
      ),
      new Trigger(Trigger.BROADCAST, { name: "Intro" }, this.whenIReceiveIntro),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Impact" },
        this.whenIReceiveImpact
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Hexplosion" },
        this.whenIReceiveHexplosion
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "GAME START" },
        this.whenIReceiveGameStart2
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Spawn Glitches" },
        this.whenIReceiveSpawnGlitches
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "GAME START" },
        this.whenIReceiveGameStart3
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "GAME START" },
        this.whenIReceiveGameStart4
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "End Rays" },
        this.whenIReceiveEndRays
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "GAME START" },
        this.whenIReceiveGameStart5
      ),
      new Trigger(Trigger.CLONE_START, this.startAsClone),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Impact" },
        this.whenIReceiveImpact2
      ),
    ];

    this.audioEffects.volume = 25;

    this.vars.i = 1;
    this.vars.instance = "BASE";
    this.vars.achievements = ["FROG", "MAZE"];
  }

  *whenGreenFlagClicked() {
    this.vars.instance = "BASE";
    this.stage.vars.Scrollx = 0;
    this.stage.vars.Scrolly = 0;
    this.goto(0, 0);
    this.visible = false;
    yield* this.setAchievements();
    this.stage.vars.Progress = 0;
    this.stage.vars.Froghint = "FALSE";
    this.stage.vars.Cuphint = "FALSE";
    yield* this.broadcastAndWait("PRE_GAME");
    yield* this.broadcastAndWait("Setup");
    yield* this.broadcastAndWait("Loading");
    yield* this.toggleClickGuard("ON");
    yield* this.broadcastAndWait("Intro");
    yield* this.toggleClickGuard("OFF");
    this.restartTimer();
    this.broadcast("GAME START");
    this.broadcast("Position Objects");
    yield* this.startSound("Zip");
    yield* this.wait(0.5);
    this.stage.vars.Speech = 1;
    this.broadcast("Start Speaking");
    while (!(this.toNumber(this.stage.vars.Progress) === 1)) {
      yield;
    }
    this.stage.vars.Speech = 2;
    this.broadcast("Start Speaking");
    while (!(this.toNumber(this.stage.vars.Progress) === 2)) {
      yield;
    }
    this.stage.vars.Speech = 3;
    this.broadcast("Start Speaking");
    while (!(this.toNumber(this.stage.vars.Progress) === 3)) {
      yield;
    }
    this.stage.vars.Speech = 4;
    this.broadcast("Start Speaking");
    while (!(this.toNumber(this.stage.vars.Progress) === 4)) {
      yield;
    }
    this.stage.vars.Speech = 5;
    this.broadcast("Start Speaking");
    while (!(this.toNumber(this.stage.vars.Progress) === 5)) {
      yield;
    }
    this.stage.vars.Speech = 6;
    this.broadcast("Start Speaking");
    while (!(this.toNumber(this.stage.vars.Progress) === 6)) {
      yield;
    }
    this.stage.vars.Speech = 7;
    this.broadcast("Start Speaking");
    while (!(this.toNumber(this.stage.vars.Progress) === 7)) {
      yield;
    }
    this.broadcast("Drop Speaker");
    yield* this.toggleClickGuard("ON");
    this.stage.vars.Speech = 8;
    this.broadcast("Start Speaking");
    while (!(this.toNumber(this.stage.vars.Progress) === 8)) {
      yield;
    }
    yield* this.toggleClickGuard("OFF");
    while (!(this.toNumber(this.stage.vars.Progress) === 9)) {
      yield;
    }
    this.stage.vars.Speech = 9;
    this.broadcast("Start Speaking");
    while (!(this.toNumber(this.stage.vars.Progress) === 10)) {
      yield;
    }
    this.stage.vars.Speech = 10;
    this.broadcast("Start Speaking");
    while (!(this.toNumber(this.stage.vars.Progress) === 11)) {
      yield;
    }
    this.stage.vars.Speech = 11;
    this.broadcast("Start Speaking");
    while (!(this.toNumber(this.stage.vars.Progress) === 12)) {
      yield;
    }
    this.stage.vars.Speech = 12;
    this.broadcast("Start Speaking");
    while (!(this.toNumber(this.stage.vars.Progress) === 13)) {
      yield;
    }
    this.stage.vars.Speech = 13;
    this.broadcast("Start Speaking");
    while (!(this.toNumber(this.stage.vars.Progress) === 14)) {
      yield;
    }
    this.stage.vars.Speech = 14;
    this.broadcast("Start Speaking");
    while (!(this.toNumber(this.stage.vars.Progress) === 15)) {
      yield;
    }
    this.stage.vars.Speech = 15;
    this.broadcast("Start Speaking");
    while (!(this.toNumber(this.stage.vars.Progress) === 16)) {
      yield;
    }
    this.stage.vars.Speech = 16;
    this.broadcast("Start Speaking");
    while (!(this.toNumber(this.stage.vars.Progress) === 19)) {
      yield;
    }
    this.audioEffects.volume = 0;
    this.stage.vars.Speech = 19;
    this.broadcast("Start Speaking");
    yield* this.wait(1);
    this.stage.vars.Achievementcode = "EXIT";
    this.broadcast("Unlock Achievement");
    while (!(this.toNumber(this.stage.vars.Progress) === 20)) {
      yield;
    }
    /* TODO: Implement stop other scripts in sprite */ null;
    yield* this.toggleClickGuard("ON");
    this.stage.vars.Speech = 31;
    this.broadcast("Start Speaking");
  }

  *whenIReceiveCheckWord() {
    yield* this.checkword();
  }

  *setAchievements() {
    this.vars.achievements = [];
    this.vars.achievements.push("FROG");
    this.vars.achievements.push("MAZE");
  }

  *checkword() {
    this.vars.i = 0;
    for (let i = 0; i < this.vars.achievements.length; i++) {
      this.vars.i++;
      if (
        this.compare(
          this.itemOf(this.vars.achievements, this.vars.i - 1),
          this.stage.vars.word.join(" ")
        ) === 0
      ) {
        this.stage.vars.Achievementcode = this.stage.vars.word.join(" ");
        this.vars.achievements.splice(this.vars.i - 1, 1);
        this.broadcast("Unlock Achievement");
        return;
      }
    }
  }

  *whenIReceiveGameStart() {
    while (!(this.toString(this.stage.vars.Seenfire) === "TRUE")) {
      yield;
    }
    this.stage.vars.Speech = 24;
    this.broadcast("Start Speaking");
  }

  *whenIReceiveGameTune() {
    this.audioEffects.volume = 50;
    while (!(this.toNumber(this.stage.vars.Progress) === 19)) {
      yield* this.playSoundUntilDone("Music");
      yield;
    }
  }

  *whenIReceiveStopSounds() {
    for (let i = 0; i < 50; i++) {
      this.audioEffects.volume -= 2;
      yield;
    }
    this.stopAllSounds();
    this.audioEffects.volume = 50;
  }

  *whenIReceiveRoomSound() {
    if (
      this.compare(this.stage.vars.Scrollx, 960) < 0 ||
      this.compare(this.stage.vars.Scrolly, 0) < 0
    ) {
      this.audioEffects.volume = 25;
    } else {
      this.audioEffects.volume = 50;
    }
  }

  *whenIReceiveClickGuardOn() {
    yield* this.toggleClickGuard("ON");
  }

  *whenIReceiveClickGuardOff() {
    yield* this.toggleClickGuard("OFF");
  }

  *toggleClickGuard(state) {
    if (this.toString(state) === "ON") {
      this.stage.vars.Clickguard = "TRUE";
      this.costume = "Game";
      this.moveAhead();
      this.effects.clear();
      this.effects.ghost = 99;
      this.visible = true;
    } else {
      this.stage.vars.Clickguard = "FALSE";
      this.visible = false;
    }
  }

  *whenIReceiveHum() {
    this.audioEffects.volume = 50;
    yield* this.startSound("Hum");
  }

  *whenIReceiveEndMusic() {
    this.stopAllSounds();
    this.audioEffects.volume = 40;
    while (true) {
      yield* this.playSoundUntilDone("Finish");
      yield;
    }
  }

  *whenIReceiveEndOfGame() {
    /* TODO: Implement stop other scripts in sprite */ null;
    this.broadcast("End Music");
    this.costume = "Credits";
    this.effects.clear();
    this.effects.ghost = 100;
    this.visible = true;
    for (let i = 0; i < 50; i++) {
      this.effects.ghost -= 2;
      yield;
    }
    yield* this.wait(1);
    this.broadcast("Scrolling Text");
  }

  *whenIReceiveThumb() {
    this.goto(0, 0);
    this.costume = "OutOfOrder";
    this.effects.clear();
    this.moveAhead();
    this.visible = true;
  }

  *zipSound() {
    this.stopAllSounds();
    this.audioEffects.volume = 50;
    yield* this.startSound("Zip");
  }

  *whenIReceivePreGame() {
    this.visible = true;
    for (let i = 0; i < 20; i++) {
      this.effects.brightness -= 5;
      yield;
    }
    this.visible = false;
    this.effects.clear();
  }

  *whenIReceiveIntro() {
    this.audioEffects.volume = 100;
    yield* this.startSound("Hum");
    this.moveAhead();
    this.costume = "Title";
    this.effects.ghost = 100;
    this.effects.brightness = -100;
    this.visible = true;
    yield* this.wait(1);
    for (let i = 0; i < 100; i++) {
      this.effects.ghost -= 1;
      this.effects.brightness += 1;
      yield;
    }
    yield* this.wait(1);
    this.createClone();
    yield* this.wait(5);
    this.broadcast("Impact");
    this.stopAllSounds();
    yield* this.startSound("BoxDrop");
    this.costume = "OutOfOrder";
    yield* this.wait(3);
    for (let i = 0; i < 20; i++) {
      this.effects.brightness -= 5;
      yield;
    }
    this.costume = "Game";
    this.effects.clear();
    this.broadcast("Fade In Game");
    yield* this.wait(2);
    for (let i = 0; i < 100; i++) {
      this.effects.ghost += 1;
      yield;
    }
  }

  *wobble() {
    this.x += 2;
    this.y -= 2;
    yield* this.wait(0.04);
    this.x -= 6;
    yield* this.wait(0.04);
    this.x += 2;
    this.y += 2;
    yield* this.wait(0.04);
    this.goto(0, 0);
  }

  *whenIReceiveImpact() {
    yield* this.wobble();
  }

  *whenIReceiveHexplosion() {
    yield* this.toggleClickGuard("ON");
    this.stage.vars.explosionx.push(960);
    this.stage.vars.explosiony.push(-30);
    yield* this.wait(0.05);
    this.stage.vars.explosionx.push(1000);
    this.stage.vars.explosiony.push(-100);
    yield* this.wait(0.05);
    this.stage.vars.explosionx.push(920);
    this.stage.vars.explosiony.push(-100);
    yield* this.wait(0.05);
    this.stage.vars.explosionx.push(960);
    this.stage.vars.explosiony.push(-150);
    yield* this.wait(0.05);
    this.stage.vars.explosionx.push(960);
    this.stage.vars.explosiony.push(-77);
    this.broadcast("Hide Barrel");
    yield* this.wait(1);
    this.stage.vars.Speech = 17;
    this.broadcast("Start Speaking");
    yield* this.wait(2);
    this.stage.vars.Achievementcode = "BOMB";
    this.broadcast("Unlock Achievement");
    this.stage.vars.Progress++;
    yield* this.wait(2);
    this.stage.vars.Spawning = "TRUE";
    this.broadcast("Spawn Glitches");
    while (!(this.toString(this.stage.vars.Spawning) === "FALSE")) {
      yield;
    }
    yield* this.toggleClickGuard("OFF");
  }

  *whenIReceiveGameStart2() {
    while (!(this.toString(this.stage.vars.Seenbomb) === "TRUE")) {
      yield;
    }
    this.stage.vars.Speech = 25;
    this.broadcast("Start Speaking");
  }

  *whenIReceiveSpawnGlitches() {
    this.broadcast("Game Tune");
    this.stage.vars.Speech = 18;
    this.broadcast("Start Speaking");
  }

  *whenIReceiveGameStart3() {
    while (!(this.toString(this.stage.vars.Seenmachine) === "TRUE")) {
      yield;
    }
    this.stage.vars.Speech = 26;
    this.broadcast("Start Speaking");
  }

  *whenIReceiveGameStart4() {
    while (!(this.toString(this.stage.vars.Seenstorage) === "TRUE")) {
      yield;
    }
    this.stage.vars.Speech = 27;
    this.broadcast("Start Speaking");
  }

  *whenIReceiveEndRays() {
    this.audioEffects.volume = 0;
  }

  *whenIReceiveGameStart5() {
    while (!(this.toString(this.stage.vars.Seenballoon) === "TRUE")) {
      yield;
    }
    this.stage.vars.Speech = 30;
    this.broadcast("Start Speaking");
  }

  *startAsClone() {
    this.vars.instance = "CLONE";
    this.costume = "PARTII";
    this.effects.ghost = 100;
    this.effects.brightness = -100;
    this.moveAhead();
    this.visible = true;
    for (let i = 0; i < 100; i++) {
      this.effects.ghost -= 1;
      this.effects.brightness += 1;
      yield;
    }
  }

  *whenIReceiveImpact2() {
    if (this.toString(this.vars.instance) === "CLONE") {
      this.deleteThisClone();
    }
  }
}
