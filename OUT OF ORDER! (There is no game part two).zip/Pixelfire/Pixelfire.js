/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Pixelfire extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("PixelFire", "./Pixelfire/costumes/PixelFire.png", {
        x: 48,
        y: 58,
      }),
      new Costume("PixelFire2", "./Pixelfire/costumes/PixelFire2.png", {
        x: 48,
        y: 58,
      }),
      new Costume("PixelFire3", "./Pixelfire/costumes/PixelFire3.png", {
        x: 48,
        y: 58,
      }),
      new Costume("PixelFire4", "./Pixelfire/costumes/PixelFire4.png", {
        x: 48,
        y: 58,
      }),
      new Costume("PixelFire5", "./Pixelfire/costumes/PixelFire5.png", {
        x: 48,
        y: 58,
      }),
      new Costume("PixelFire6", "./Pixelfire/costumes/PixelFire6.png", {
        x: 48,
        y: 58,
      }),
      new Costume("PixelFire7", "./Pixelfire/costumes/PixelFire7.png", {
        x: 48,
        y: 58,
      }),
      new Costume("PixelFire8", "./Pixelfire/costumes/PixelFire8.png", {
        x: 48,
        y: 58,
      }),
      new Costume("PixelFire9", "./Pixelfire/costumes/PixelFire9.png", {
        x: 48,
        y: 58,
      }),
      new Costume("PixelFire10", "./Pixelfire/costumes/PixelFire10.png", {
        x: 48,
        y: 58,
      }),
      new Costume("PixelFire11", "./Pixelfire/costumes/PixelFire11.png", {
        x: 48,
        y: 58,
      }),
      new Costume("PixelFire12", "./Pixelfire/costumes/PixelFire12.png", {
        x: 48,
        y: 58,
      }),
      new Costume("PixelFire13", "./Pixelfire/costumes/PixelFire13.png", {
        x: 48,
        y: 58,
      }),
      new Costume("PixelFire14", "./Pixelfire/costumes/PixelFire14.png", {
        x: 48,
        y: 58,
      }),
      new Costume("PixelFire15", "./Pixelfire/costumes/PixelFire15.png", {
        x: 48,
        y: 58,
      }),
      new Costume("PixelFire16", "./Pixelfire/costumes/PixelFire16.png", {
        x: 48,
        y: 58,
      }),
      new Costume("PixelFire17", "./Pixelfire/costumes/PixelFire17.png", {
        x: 48,
        y: 58,
      }),
      new Costume("PixelFire18", "./Pixelfire/costumes/PixelFire18.png", {
        x: 48,
        y: 58,
      }),
    ];

    this.sounds = [];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "GAME START" },
        this.whenIReceiveGameStart
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Position Objects" },
        this.whenIReceivePositionObjects
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Impact" },
        this.whenIReceiveImpact
      ),
      new Trigger(Trigger.BROADCAST, { name: "Setup" }, this.whenIReceiveSetup),
      new Trigger(
        Trigger.BROADCAST,
        { name: "End Fire" },
        this.whenIReceiveEndFire
      ),
      new Trigger(Trigger.CLICKED, this.whenthisspriteclicked),
    ];

    this.vars.x = -660;
    this.vars.y = -120;
    this.vars.firedone = "FALSE";
    this.vars.hotwarning = "FALSE";
  }

  *whenGreenFlagClicked() {
    this.vars.firedone = "FALSE";
    this.goto(-180, -120);
    this.costume = "PixelFire";
    this.visible = false;
  }

  *whenIReceiveGameStart() {
    while (true) {
      while (!(this.compare(this.stage.vars.Scrollx, 0) < 0)) {
        yield;
      }
      this.costumeNumber++;
      yield* this.wait(0.1);
      yield;
    }
  }

  *whenIReceivePositionObjects() {
    if (this.toString(this.vars.firedone) === "FALSE") {
      yield* this.position();
    }
  }

  *position() {
    this.goto(
      this.toNumber(this.vars.x) - this.toNumber(this.stage.vars.Scrollx),
      this.toNumber(this.vars.y) - this.toNumber(this.stage.vars.Scrolly)
    );
    if (
      this.compare(
        this.x,
        this.toNumber(this.vars.x) - this.toNumber(this.stage.vars.Scrollx)
      ) === 0 &&
      this.compare(
        this.y,
        this.toNumber(this.vars.y) - this.toNumber(this.stage.vars.Scrolly)
      ) === 0
    ) {
      this.visible = true;
    } else {
      this.visible = false;
    }
  }

  *whenIReceiveImpact() {
    if (this.toString(this.vars.firedone) === "FALSE") {
      yield* this.wobble();
    }
  }

  *wobble() {
    this.x += 2;
    this.y -= 2;
    yield* this.wait(0.04);
    this.x -= 6;
    yield* this.wait(0.04);
    this.x += 2;
    this.y += 2;
    yield* this.wait(0.04);
    this.goto(
      this.toNumber(this.vars.x) - this.toNumber(this.stage.vars.Scrollx),
      this.toNumber(this.vars.y) - this.toNumber(this.stage.vars.Scrolly)
    );
  }

  *whenIReceiveSetup() {
    this.vars.x = -660;
    this.vars.y = -120;
    this.vars.hotwarning = "FALSE";
    this.moveAhead();
  }

  *whenIReceiveEndFire() {
    this.vars.firedone = "TRUE";
    /* TODO: Implement stop other scripts in sprite */ null;
    this.visible = false;
  }

  *whenthisspriteclicked() {
    if (this.toString(this.vars.hotwarning) === "FALSE") {
      this.vars.hotwarning = "TRUE";
      this.stage.vars.Speech = 21;
      this.broadcast("Start Speaking");
    }
  }
}
