/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Ground extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Main", "./Ground/costumes/Main.svg", { x: 0, y: 0 }),
      new Costume("Goat Room", "./Ground/costumes/Goat Room.png", {
        x: 480,
        y: -168,
      }),
      new Costume("Bomb Room", "./Ground/costumes/Bomb Room.png", {
        x: 480,
        y: -168,
      }),
      new Costume("Bomb Room2", "./Ground/costumes/Bomb Room2.png", {
        x: 480,
        y: -168,
      }),
      new Costume("ExitGround", "./Ground/costumes/ExitGround.png", {
        x: 480,
        y: 360,
      }),
      new Costume("OutsideGround", "./Ground/costumes/OutsideGround.png", {
        x: 480,
        y: 92,
      }),
      new Costume("StoreRoomGround", "./Ground/costumes/StoreRoomGround.png", {
        x: 480,
        y: 360,
      }),
      new Costume("DungeonGround", "./Ground/costumes/DungeonGround.png", {
        x: 480,
        y: 360,
      }),
      new Costume("DungeonGround2", "./Ground/costumes/DungeonGround2.png", {
        x: 480,
        y: 360,
      }),
      new Costume("DungeonGround3", "./Ground/costumes/DungeonGround3.png", {
        x: 480,
        y: 360,
      }),
    ];

    this.sounds = [new Sound("Game Music", "./Ground/sounds/Game Music.mp3")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Position Objects" },
        this.whenIReceivePositionObjects
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Impact" },
        this.whenIReceiveImpact
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Fade In Game" },
        this.whenIReceiveFadeInGame
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "CLEAR EVERYTHING" },
        this.whenIReceiveClearEverything
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "GAME START" },
        this.whenIReceiveGameStart
      ),
      new Trigger(Trigger.CLONE_START, this.startAsClone),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Hide Barrel" },
        this.whenIReceiveHideBarrel
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Hide Button" },
        this.whenIReceiveHideButton
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "End Rays" },
        this.whenIReceiveEndRays
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Sunset" },
        this.whenIReceiveSunset
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Escape" },
        this.whenIReceiveEscape
      ),
    ];

    this.vars.x = 0;
    this.vars.y = 0;
    this.vars.instance = "BASE";
  }

  *whenGreenFlagClicked() {
    this.vars.instance = "BASE";
    this.goto(0, 0);
    this.visible = false;
  }

  *whenIReceivePositionObjects() {
    yield* this.position();
  }

  *position() {
    this.size = 800;
    this.goto(
      this.toNumber(this.vars.x) - this.toNumber(this.stage.vars.Scrollx),
      this.toNumber(this.vars.y) - this.toNumber(this.stage.vars.Scrolly)
    );
    this.size = 100;
    this.visible = true;
  }

  *whenIReceiveImpact() {
    yield* this.wobble(2, -2);
    yield* this.wobble(-6, 0);
    yield* this.wobble(2, 2);
    yield* this.resetwobble();
  }

  *whenIReceiveFadeInGame() {
    this.vars.instance = "CLONE";
    yield* this.createRooms();
    this.vars.x = 0;
    this.vars.y = 0;
    this.costume = "Main";
    this.vars.instance = "BASE";
  }

  *whenIReceiveClearEverything() {
    /* TODO: Implement stop other scripts in sprite */ null;
    this.visible = false;
    if (!(this.toString(this.vars.instance) === "BASE")) {
      this.stage.vars.Clonecount--;
      this.deleteThisClone();
    }
  }

  *createRooms() {
    this.warp(this.createRoomAtCostume)(480, 0, "Goat Room");
    this.warp(this.createRoomAtCostume)(960, 0, "Bomb Room");
    this.warp(this.createRoomAtCostume)(960, -360, "DungeonGround");
    this.warp(this.createRoomAtCostume)(480, -360, "StoreRoomGround");
    this.warp(this.createRoomAtCostume)(1440, -360, "ExitGround");
    this.warp(this.createRoomAtCostume)(1440, 1416, "OutsideGround");
  }

  *whenIReceiveGameStart() {
    this.moveAhead();
    yield* this.position();
  }

  *startAsClone() {
    this.vars.instance = this.costume.name;
    this.stage.vars.Clonecount++;
  }

  *whenIReceiveHideBarrel() {
    if (this.costume.name === "Bomb Room") {
      this.costumeNumber++;
      this.broadcast("Drop Visible Objects");
    }
  }

  *whenIReceiveHideButton() {
    if (this.toString(this.vars.instance) === "DungeonGround") {
      this.moveAhead();
      this.costumeNumber++;
      this.broadcast("Drop Visible Objects");
    }
  }

  *whenIReceiveEndRays() {
    if (this.toString(this.vars.instance) === "DungeonGround") {
      yield* this.startSound("Game Music");
      this.costumeNumber++;
    }
  }

  *whenIReceiveSunset() {
    if (this.costume.name === "OutsideGround") {
      this.effects.clear();
      yield* this.wait(3);
      for (let i = 0; i < 200; i++) {
        this.effects.color += 0.5;
        this.effects.brightness -= 0.5;
        yield;
      }
    }
  }

  *whenIReceiveEscape() {
    if (this.costume.name === "OutsideGround") {
      this.effects.clear();
    }
  }

  *createRoomAtCostume(x, y, costume) {
    this.vars.x = x;
    this.vars.y = y;
    this.costume = costume;
    this.createClone();
  }

  *resetwobble() {
    this.size = 800;
    this.goto(
      this.toNumber(this.vars.x) - this.toNumber(this.stage.vars.Scrollx),
      this.toNumber(this.vars.y) - this.toNumber(this.stage.vars.Scrolly)
    );
    this.size = 100;
  }

  *wobble(x, y) {
    this.size = 800;
    this.x += this.toNumber(x);
    this.y += this.toNumber(y);
    this.size = 100;
    yield* this.wait(0.04);
  }
}
