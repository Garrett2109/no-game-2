/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Cursor extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Y1", "./Cursor/costumes/Y1.png", { x: 12, y: 12 }),
      new Costume("Y2", "./Cursor/costumes/Y2.png", { x: 12, y: 12 }),
      new Costume("Y3", "./Cursor/costumes/Y3.png", { x: 12, y: 12 }),
      new Costume("Y4", "./Cursor/costumes/Y4.png", { x: 12, y: 12 }),
      new Costume("N1", "./Cursor/costumes/N1.png", { x: 28, y: 28 }),
      new Costume("N2", "./Cursor/costumes/N2.png", { x: 20, y: 20 }),
      new Costume("N3", "./Cursor/costumes/N3.png", { x: 12, y: 12 }),
      new Costume("N4", "./Cursor/costumes/N4.png", { x: 20, y: 20 }),
      new Costume("EndCursor", "./Cursor/costumes/EndCursor.png", {
        x: 52,
        y: 28,
      }),
    ];

    this.sounds = [];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "END OF GAME" },
        this.whenIReceiveEndOfGame
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "_THUMB" },
        this.whenIReceiveThumb
      ),
    ];

    this.vars.costumeCounter = 341087;
  }

  *whenGreenFlagClicked() {
    this.size = 40;
    this.visible = false;
    this.vars.costumeCounter = 0;
    this.stage.vars.Clickguard = "FALSE";
    while (true) {
      while (!(this.toString(this.stage.vars.Clickguard) === "TRUE")) {
        yield;
      }
      this.visible = true;
      while (!(this.toString(this.stage.vars.Clickguard) === "FALSE")) {
        this.costume =
          "N" +
          this.toString(
            (Math.ceil(this.toNumber(this.vars.costumeCounter) / 2) % 4) + 1
          );
        this.goto(this.mouse.x, this.mouse.y);
        this.moveAhead();
        this.vars.costumeCounter++;
        yield;
      }
      this.visible = false;
      yield;
    }
  }

  *whenIReceiveEndOfGame() {
    /* TODO: Implement stop other scripts in sprite */ null;
    this.costume = "EndCursor";
    this.visible = true;
    while (true) {
      this.goto(this.mouse.x, this.mouse.y);
      this.moveAhead();
      yield;
    }
  }

  *whenIReceiveThumb() {
    this.visible = false;
  }
}
