/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Arrow extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Arrow", "./Arrow/costumes/Arrow.png", { x: 64, y: 120 }),
      new Costume("Arrow2", "./Arrow/costumes/Arrow2.png", { x: 64, y: 120 }),
    ];

    this.sounds = [
      new Sound("Arrow", "./Arrow/sounds/Arrow.mp3"),
      new Sound("Achievement", "./Arrow/sounds/Achievement.mp3"),
    ];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.CLONE_START, this.startAsClone),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Position Objects" },
        this.whenIReceivePositionObjects
      ),
      new Trigger(Trigger.BROADCAST, { name: "Setup" }, this.whenIReceiveSetup),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Impact" },
        this.whenIReceiveImpact
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Unlock Achievement" },
        this.whenIReceiveUnlockAchievement
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "CLEAR EVERYTHING" },
        this.whenIReceiveClearEverything
      ),
    ];

    this.vars.counter = 26678;
    this.vars.instance = "BASE";
    this.vars.x = 1180;
    this.vars.y = -360;
    this.vars.unlockcode = "EXIT";
    this.vars.unlocked = 0;
  }

  *whenGreenFlagClicked() {
    this.vars.instance = "BASE";
    this.size = 40;
    this.visible = false;
  }

  *startAsClone() {
    this.vars.instance = "CLONE";
    this.stage.vars.Clonecount++;
    this.vars.unlocked = "FALSE";
    this.vars.counter = 0;
    while (!(this.toString(this.vars.unlocked) === "TRUE")) {
      yield;
    }
    yield* this.position();
    while (true) {
      this.vars.counter++;
      yield* this.flash();
      if (
        this.touching("mouse") &&
        this.mouse.down &&
        this.toString(this.stage.vars.Clickguard) === "FALSE" &&
        this.toString(this.stage.vars.Scrolling) === "FALSE"
      ) {
        if (
          this.compare(
            this.x,
            this.toNumber(this.vars.x) - this.toNumber(this.stage.vars.Scrollx)
          ) === 0 &&
          this.compare(
            this.y,
            this.toNumber(this.vars.y) - this.toNumber(this.stage.vars.Scrolly)
          ) === 0 &&
          this.toString(this.vars.unlocked) === "TRUE"
        ) {
          yield* this.scroll();
        }
      }
      yield;
    }
  }

  *createArrows() {
    this.warp(this.createArrowAtXYDirectionUnlockCode)(220, 0, 90, "GOAT");
    this.warp(this.createArrowAtXYDirectionUnlockCode)(260, 0, -90, "GOAT");
    this.warp(this.createArrowAtXYDirectionUnlockCode)(-220, 0, -90, "MAZE");
    this.warp(this.createArrowAtXYDirectionUnlockCode)(-260, 0, 90, "MAZE");
    this.warp(this.createArrowAtXYDirectionUnlockCode)(740, 0, -90, "GATE");
    this.warp(this.createArrowAtXYDirectionUnlockCode)(700, 0, 90, "GATE");
    this.warp(this.createArrowAtXYDirectionUnlockCode)(960, -160, 180, "BOMB");
    this.warp(this.createArrowAtXYDirectionUnlockCode)(960, -200, 0, "BOMB");
    this.warp(this.createArrowAtXYDirectionUnlockCode)(740, -360, -90, "BOMB");
    this.warp(this.createArrowAtXYDirectionUnlockCode)(700, -360, 90, "BOMB");
    this.warp(this.createArrowAtXYDirectionUnlockCode)(1220, -360, -90, "EXIT");
    this.warp(this.createArrowAtXYDirectionUnlockCode)(1180, -360, 90, "EXIT");
  }

  *createArrowAtXYDirectionUnlockCode(x, y, d, code) {
    this.vars.unlockcode = code;
    this.vars.x = x;
    this.vars.y = y;
    this.direction = this.toNumber(d);
    this.createClone();
  }

  *position() {
    this.goto(
      this.toNumber(this.vars.x) - this.toNumber(this.stage.vars.Scrollx),
      this.toNumber(this.vars.y) - this.toNumber(this.stage.vars.Scrolly)
    );
    if (
      this.compare(
        this.x,
        this.toNumber(this.vars.x) - this.toNumber(this.stage.vars.Scrollx)
      ) === 0 &&
      this.compare(
        this.y,
        this.toNumber(this.vars.y) - this.toNumber(this.stage.vars.Scrolly)
      ) === 0 &&
      this.toString(this.vars.unlocked) === "TRUE"
    ) {
      this.visible = true;
    } else {
      this.visible = false;
    }
  }

  *whenIReceivePositionObjects() {
    if (this.toString(this.vars.instance) === "CLONE") {
      yield* this.position();
    }
  }

  *scroll() {
    this.broadcast("Hide Settings");
    if (
      this.direction === 90 &&
      this.compare(this.stage.vars.Scrollx, 1440) < 0
    ) {
      yield* this.startSound("Arrow");
      this.broadcast("Scroll Right");
    } else {
      if (
        this.direction === -90 &&
        this.compare(this.stage.vars.Scrollx, -480) > 0
      ) {
        yield* this.startSound("Arrow");
        this.broadcast("Scroll Left");
      } else {
        if (
          this.direction === 0 &&
          this.compare(this.stage.vars.Scrolly, 0) < 0
        ) {
          yield* this.startSound("Arrow");
          this.broadcast("Scroll Up");
        } else {
          if (
            this.direction === 180 &&
            this.compare(this.stage.vars.Scrolly, -360) > 0
          ) {
            yield* this.startSound("Arrow");
            this.broadcast("Scroll Down");
          }
        }
      }
    }
  }

  *whenIReceiveSetup() {
    yield* this.createArrows();
  }

  *wobble() {
    this.x += 2;
    this.y -= 2;
    yield* this.wait(0.04);
    this.x -= 6;
    yield* this.wait(0.04);
    this.x += 2;
    this.y += 2;
    yield* this.wait(0.04);
    this.goto(
      this.toNumber(this.vars.x) - this.toNumber(this.stage.vars.Scrollx),
      this.toNumber(this.vars.y) - this.toNumber(this.stage.vars.Scrolly)
    );
  }

  *whenIReceiveImpact() {
    yield* this.wobble();
  }

  *whenIReceiveUnlockAchievement() {
    if (this.toString(this.vars.instance) === "CLONE") {
      if (
        this.compare(this.stage.vars.Achievementcode, this.vars.unlockcode) ===
        0
      ) {
        yield* this.startSound("Achievement");
        this.vars.unlocked = "TRUE";
      }
    }
  }

  *whenIReceiveClearEverything() {
    /* TODO: Implement stop other scripts in sprite */ null;
    if (this.toString(this.vars.instance) === "CLONE") {
      this.stage.vars.Clonecount--;
      this.deleteThisClone();
    }
  }

  *flash() {
    this.costume = (Math.ceil(this.toNumber(this.vars.counter) / 4) % 2) + 1;
    this.effects.ghost =
      25 + Math.sin(this.degToRad(this.toNumber(this.vars.counter) * 10)) * 50;
  }
}
