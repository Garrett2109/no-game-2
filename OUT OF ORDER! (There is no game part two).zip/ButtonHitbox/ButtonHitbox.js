/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class ButtonHitbox extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Hitbox", "./ButtonHitbox/costumes/Hitbox.svg", {
        x: -126,
        y: -76.5,
      }),
    ];

    this.sounds = [];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.BROADCAST, { name: "Setup" }, this.whenIReceiveSetup),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Position Objects" },
        this.whenIReceivePositionObjects
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Hide Button" },
        this.whenIReceiveHideButton
      ),
    ];

    this.vars.x = 960;
    this.vars.y = -360;
    this.vars.buttonpressed = "FALSE";
  }

  *whenGreenFlagClicked() {
    this.goto(0, 0);
    this.effects.ghost = 99;
    this.visible = false;
  }

  *whenIReceiveSetup() {
    this.vars.buttonpressed = "FALSE";
    this.vars.x = 960;
    this.vars.y = -360;
    yield* this.position();
  }

  *whenIReceivePositionObjects() {
    if (this.toString(this.vars.buttonpressed) === "FALSE") {
      yield* this.position();
    }
  }

  *position() {
    this.goto(
      this.toNumber(this.vars.x) - this.toNumber(this.stage.vars.Scrollx),
      this.toNumber(this.vars.y) - this.toNumber(this.stage.vars.Scrolly)
    );
    if (
      this.compare(
        this.x,
        this.toNumber(this.vars.x) - this.toNumber(this.stage.vars.Scrollx)
      ) === 0 &&
      this.compare(
        this.y,
        this.toNumber(this.vars.y) - this.toNumber(this.stage.vars.Scrolly)
      ) === 0
    ) {
      this.visible = true;
    } else {
      this.visible = false;
    }
  }

  *whenIReceiveHideButton() {
    this.vars.buttonpressed = "TRUE";
    this.visible = false;
  }
}
