/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Lock extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Lock", "./Lock/costumes/Lock.png", { x: 202, y: 97 }),
    ];

    this.sounds = [
      new Sound("Game Music", "./Lock/sounds/Game Music.mp3"),
      new Sound(
        "goat-single-short-ble",
        "./Lock/sounds/goat-single-short-ble.mp3"
      ),
    ];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.BROADCAST, { name: "Setup" }, this.whenIReceiveSetup),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Position Objects" },
        this.whenIReceivePositionObjects
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Impact" },
        this.whenIReceiveImpact
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "GAME START" },
        this.whenIReceiveGameStart
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "GAME START" },
        this.whenIReceiveGameStart2
      ),
      new Trigger(Trigger.BROADCAST, { name: "Outro" }, this.whenIReceiveOutro),
    ];

    this.audioEffects.volume = 88;

    this.vars.x = 1440;
    this.vars.y = -470;
  }

  *whenGreenFlagClicked() {
    this.goto(0, -110);
    this.visible = false;
  }

  *whenIReceiveSetup() {
    this.vars.x = 1440;
    this.vars.y = -470;
    this.moveAhead();
    yield* this.position();
  }

  *whenIReceivePositionObjects() {
    yield* this.position();
    this.moveAhead();
  }

  *position() {
    this.goto(
      this.toNumber(this.vars.x) - this.toNumber(this.stage.vars.Scrollx),
      this.toNumber(this.vars.y) - this.toNumber(this.stage.vars.Scrolly)
    );
    if (
      this.compare(
        this.x,
        this.toNumber(this.vars.x) - this.toNumber(this.stage.vars.Scrollx)
      ) === 0 &&
      this.compare(
        this.y,
        this.toNumber(this.vars.y) - this.toNumber(this.stage.vars.Scrolly)
      ) === 0
    ) {
      this.visible = true;
    } else {
      this.visible = false;
    }
  }

  *whenIReceiveImpact() {
    yield* this.wobble();
  }

  *wobble() {
    this.x += 2;
    this.y -= 2;
    yield* this.wait(0.04);
    this.x -= 6;
    yield* this.wait(0.04);
    this.x += 2;
    this.y += 2;
    yield* this.wait(0.04);
    this.goto(
      this.toNumber(this.vars.x) - this.toNumber(this.stage.vars.Scrollx),
      this.toNumber(this.vars.y) - this.toNumber(this.stage.vars.Scrolly)
    );
  }

  *whenIReceiveGameStart() {
    while (
      !(
        this.touching(this.sprites["Key"].andClones()) &&
        this.toString(this.stage.vars.Scrolling) === "FALSE"
      )
    ) {
      yield;
    }
    yield* this.broadcastAndWait("Click Guard On");
    this.audioEffects.clear();
    yield* this.startSound("Game Music");
    this.vars.x = 99999;
    yield* this.position();
    this.broadcast("Hide Key");
    yield* this.wait(1);
    this.broadcast("Bob");
    this.stage.vars.Progress++;
  }

  *whenIReceiveGameStart2() {
    while (!(this.toNumber(this.stage.vars.Scrollx) === 1440)) {
      yield;
    }
    while (true) {
      yield* this.wait(this.random(4, 8));
      if (this.toNumber(this.stage.vars.Scrollx) === 1440) {
        this.audioEffects.pitch = this.random(-20, 20);
        this.audioEffects.volume = this.random(80, 100);
        yield* this.startSound("goat-single-short-ble");
        yield* this.wait(0.3);
      }
      yield;
    }
  }

  *whenIReceiveOutro() {
    /* TODO: Implement stop other scripts in sprite */ null;
  }
}
