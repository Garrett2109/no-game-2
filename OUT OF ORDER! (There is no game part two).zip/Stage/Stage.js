/* eslint-disable require-yield, eqeqeq */

import {
  Stage as StageBase,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Stage extends StageBase {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("backdrop1", "./Stage/costumes/backdrop1.svg", {
        x: 264.51351351351354,
        y: 198.44744744744744,
      }),
    ];

    this.sounds = [];

    this.triggers = [];

    this.vars.Progress = 11;
    this.vars.Clonecount = 300;
    this.vars.Dragging = "FALSE";
    this.vars.Clickguard = "TRUE";
    this.vars.Scrollx = 480;
    this.vars.Scrolly = 0;
    this.vars.Downsparks = "FALSE";
    this.vars.Achievementcode = "GOAT";
    this.vars.Scrolling = "FALSE";
    this.vars.Speech = 11;
    this.vars.Cuphint = "FALSE";
    this.vars.Completed = 8346;
    this.vars.WinnersList =
      "19111911191104110411991205131325372832992829303101120524233027279903010914052118060512121523373737379918050416180919130120090399";
    this.vars.ScrollingMessage =
      "YOU COMPLETED THIS GAME IN 5 MINUTES 2 SECONDS. THIS GAME HAS BEEN COMPLETED 4245 TIMES. THE LAST 5 WINNERS WERE COLINMACC, A_WISCONSIN_COW, 12HRHT, NIC_4567, MANDACITY. THIS GAME WAS INSPIRED BY THERE IS NO GAME BY KAMIZOTO. THE FROG MINI-GAME CONCEPT WAS INSPIRED BY ROKCODER. MOST GRAPHICS, SOUNDS AND MUSIC BY KAMIZOTO. OTHER GRAPHICS FOUND IN STOCK IMAGES ON GOOGLE OR MADE BY ME. GLITCH SONG BY TAYLOR SWIFT. NEVER GONNA GIVE YOU UP SONG BY RICK ASTLEY. GRIFFPATCH VOICE BY GRIFFPATCH. THE OTHER VOICE ACTING IS BY ME. THANK YOU FOR PLAYING!";
    this.vars.Time = 302.115;
    this.vars.FastestTime = 168.892;
    this.vars.Mousetouchingcheckbox = 0;
    this.vars.Griffpatch = "false";
    this.vars.Water = true;
    this.vars.Music = "false";
    this.vars.WaterComplete = "true";
    this.vars.Showingsettings = "false";
    this.vars.FliesToSpawn = 5;
    this.vars.RetractTongue = "FALSE";
    this.vars.FliesToKill = 10;
    this.vars.Froghint = "FALSE";
    this.vars.Seenfire = "FALSE";
    this.vars.Seenbomb = "FALSE";
    this.vars.Glitchcount = 0;
    this.vars.Spawning = "FALSE";
    this.vars.Seenmachine = "FALSE";
    this.vars.Seenstorage = "FALSE";
    this.vars.Seenballoon = "FALSE";
    this.vars.rotation = -7.295205472410351;
    this.vars.angle = 5.660017273121484;
    this.vars.rotationChange = -0.5660017273121485;
    this.vars.friction = 0.15;
    this.vars.SpawnedCarry = "FALSE";
    this.vars.sparksx = [];
    this.vars.sparksy = [];
    this.vars.word = ["G", "A", "M", "E"];
    this.vars.wordx = [-40, -11, 18, 47];
    this.vars.wordy = [-11, -11, -11, -11];
    this.vars.waterx = [];
    this.vars.watery = [];
    this.vars.sparkstype = [];
    this.vars.letterx = [];
    this.vars.lettery = [];
    this.vars.lettertype = [];
    this.vars.explosionx = [];
    this.vars.explosiony = [];
  }
}
