/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Hexplode extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Boom2", "./Hexplode/costumes/Boom2.png", { x: 80, y: 119 }),
      new Costume("Boom3", "./Hexplode/costumes/Boom3.png", { x: 80, y: 119 }),
      new Costume("Boom4", "./Hexplode/costumes/Boom4.png", { x: 80, y: 119 }),
      new Costume("Boom5", "./Hexplode/costumes/Boom5.png", { x: 80, y: 119 }),
      new Costume("Boom6", "./Hexplode/costumes/Boom6.png", { x: 80, y: 119 }),
      new Costume("Boom7", "./Hexplode/costumes/Boom7.png", { x: 80, y: 119 }),
      new Costume("Boom8", "./Hexplode/costumes/Boom8.png", { x: 80, y: 119 }),
      new Costume("Boom9", "./Hexplode/costumes/Boom9.png", { x: 80, y: 119 }),
      new Costume("Boom10", "./Hexplode/costumes/Boom10.png", {
        x: 80,
        y: 119,
      }),
      new Costume("Boom11", "./Hexplode/costumes/Boom11.png", {
        x: 80,
        y: 119,
      }),
      new Costume("Boom12", "./Hexplode/costumes/Boom12.png", {
        x: 80,
        y: 119,
      }),
      new Costume("Boom13", "./Hexplode/costumes/Boom13.png", {
        x: 80,
        y: 119,
      }),
      new Costume("Boom14", "./Hexplode/costumes/Boom14.png", {
        x: 80,
        y: 119,
      }),
      new Costume("Boom15", "./Hexplode/costumes/Boom15.png", {
        x: 80,
        y: 119,
      }),
      new Costume("Boom16", "./Hexplode/costumes/Boom16.png", {
        x: 80,
        y: 119,
      }),
      new Costume("Boom17", "./Hexplode/costumes/Boom17.png", {
        x: 80,
        y: 119,
      }),
      new Costume("Boom18", "./Hexplode/costumes/Boom18.png", {
        x: 80,
        y: 119,
      }),
      new Costume("Boom19", "./Hexplode/costumes/Boom19.png", {
        x: 80,
        y: 119,
      }),
      new Costume("Boom20", "./Hexplode/costumes/Boom20.png", {
        x: 80,
        y: 119,
      }),
      new Costume("Boom21", "./Hexplode/costumes/Boom21.png", {
        x: 80,
        y: 119,
      }),
    ];

    this.sounds = [
      new Sound("Fireworks4", "./Hexplode/sounds/Fireworks4.mp3"),
      new Sound("Fireworks5", "./Hexplode/sounds/Fireworks5.mp3"),
      new Sound("FireWorks2", "./Hexplode/sounds/FireWorks2.wav"),
      new Sound("FireworkFinal", "./Hexplode/sounds/FireworkFinal.wav"),
      new Sound("Hexplode_Bash", "./Hexplode/sounds/Hexplode_Bash.wav"),
      new Sound("Hexplode_Bash3", "./Hexplode/sounds/Hexplode_Bash3.wav"),
      new Sound("Hexplode_big1", "./Hexplode/sounds/Hexplode_big1.wav"),
      new Sound("Hexplode_Big3", "./Hexplode/sounds/Hexplode_Big3.wav"),
      new Sound("Hexplode_Final", "./Hexplode/sounds/Hexplode_Final.wav"),
      new Sound("DeepHexplode", "./Hexplode/sounds/DeepHexplode.wav"),
    ];

    this.triggers = [
      new Trigger(Trigger.CLONE_START, this.startAsClone),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "GAME START" },
        this.whenIReceiveGameStart
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "CLEAR EVERYTHING" },
        this.whenIReceiveClearEverything
      ),
    ];

    this.vars.instance = "BASE";
    this.vars.x = 960;
    this.vars.y = -77;
  }

  *startAsClone() {
    this.vars.instance = "CLONE";
    this.stage.vars.Clonecount++;
    this.costume = "Boom2";
    this.moveAhead();
    yield* this.startSound("Hexplode_Bash");
    while (true) {
      yield* this.position();
      this.costumeNumber++;
      if (this.costumeNumber === 20) {
        this.stage.vars.Clonecount--;
        this.deleteThisClone();
      }
      yield;
    }
  }

  *whenGreenFlagClicked() {
    this.vars.instance = "BASE";
    this.size = 200;
    this.visible = false;
  }

  *position() {
    this.goto(
      this.toNumber(this.vars.x) - this.toNumber(this.stage.vars.Scrollx),
      this.toNumber(this.vars.y) - this.toNumber(this.stage.vars.Scrolly)
    );
    if (
      this.compare(
        this.x,
        this.toNumber(this.vars.x) - this.toNumber(this.stage.vars.Scrollx)
      ) === 0 &&
      this.compare(
        this.y,
        this.toNumber(this.vars.y) - this.toNumber(this.stage.vars.Scrolly)
      ) === 0
    ) {
      this.visible = true;
    } else {
      this.visible = false;
    }
  }

  *whenIReceiveGameStart() {
    if (this.toString(this.vars.instance) === "BASE") {
      this.stage.vars.explosionx = [];
      this.stage.vars.explosiony = [];
      while (true) {
        while (!(this.compare(this.stage.vars.explosiony.length, 0) > 0)) {
          yield;
        }
        this.vars.x = this.itemOf(this.stage.vars.explosionx, 0);
        this.vars.y = this.itemOf(this.stage.vars.explosiony, 0);
        this.stage.vars.explosionx.splice(0, 1);
        this.stage.vars.explosiony.splice(0, 1);
        this.createClone();
        yield;
      }
    }
  }

  *whenIReceiveClearEverything() {
    /* TODO: Implement stop other scripts in sprite */ null;
    if (!(this.toString(this.vars.instance) === "BASE")) {
      this.stage.vars.Clonecount--;
      this.deleteThisClone();
    }
  }
}
