/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Splash2 extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./Splash2/costumes/costume1.svg", {
        x: 2.5263949999999795,
        y: 3.320409999999953,
      }),
    ];

    this.sounds = [];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.CLONE_START, this.startAsClone),
      new Trigger(Trigger.BROADCAST, { name: "Setup" }, this.whenIReceiveSetup),
      new Trigger(
        Trigger.BROADCAST,
        { name: "GAME START" },
        this.whenIReceiveGameStart
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "CLEAR EVERYTHING" },
        this.whenIReceiveClearEverything
      ),
    ];

    this.vars.instance = "BASE";
    this.vars.xvel = 0.24315330918113873;
    this.vars.yvel = -20;
  }

  *whenGreenFlagClicked() {
    this.vars.instance = "BASE";
    this.visible = false;
  }

  *startAsClone() {
    if (this.toString(this.vars.instance) === "SPAWNER") {
      this.vars.instance = "CLONE";
      yield* this.createSplash();
    }
    this.stage.vars.Clonecount++;
    this.size += this.random(20, 40) * 2;
    this.effects.brightness = this.random(-25, 75);
    this.direction += this.random(0, 3) * 90;
    this.visible = true;
    this.vars.xvel = this.random(-2, 2);
    this.vars.yvel = this.random(4, 8);
    this.moveAhead();
    while (
      !(
        this.compare(this.y, -177) < 0 ||
        this.touching(this.sprites["Ground"].andClones())
      )
    ) {
      this.vars.yvel--;
      this.vars.xvel = this.toNumber(this.vars.xvel) * 0.9;
      this.x += this.toNumber(this.vars.xvel);
      this.y += this.toNumber(this.vars.yvel);
      yield;
    }
    this.stage.vars.Clonecount--;
    this.deleteThisClone();
  }

  *cloneSplash() {
    while (!(this.stage.vars.watery.length === 0)) {
      this.goto(
        this.toNumber(this.itemOf(this.stage.vars.waterx, 0)),
        this.toNumber(this.itemOf(this.stage.vars.watery, 0))
      );
      this.stage.vars.waterx.splice(0, 1);
      this.stage.vars.watery.splice(0, 1);
      this.vars.instance = "SPAWNER";
      this.createClone();
    }
  }

  *whenIReceiveSetup() {
    this.moveAhead();
    this.stage.vars.waterx = [];
    this.stage.vars.watery = [];
  }

  *whenIReceiveGameStart() {
    while (true) {
      while (!(this.compare(this.stage.vars.watery.length, 0) > 0)) {
        yield;
      }
      yield* this.cloneSplash();
      yield;
    }
  }

  *createSplash() {
    for (let i = 0; i < 30; i++) {
      this.createClone();
    }
  }

  *whenIReceiveClearEverything() {
    /* TODO: Implement stop other scripts in sprite */ null;
  }
}
