/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Candle extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Candle1", "./Candle/costumes/Candle1.png", { x: 64, y: 64 }),
      new Costume("Candle2", "./Candle/costumes/Candle2.png", { x: 64, y: 64 }),
    ];

    this.sounds = [];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Fade In Game" },
        this.whenIReceiveFadeInGame
      ),
      new Trigger(Trigger.CLONE_START, this.startAsClone),
      new Trigger(
        Trigger.BROADCAST,
        { name: "GAME START" },
        this.whenIReceiveGameStart
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Position Objects" },
        this.whenIReceivePositionObjects
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Impact" },
        this.whenIReceiveImpact
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "CLEAR EVERYTHING" },
        this.whenIReceiveClearEverything
      ),
    ];

    this.vars.instance = "BASE";
    this.vars.x = 1120;
    this.vars.y = -330;
  }

  *whenGreenFlagClicked() {
    this.vars.instance = "BASE";
    this.size = 100;
    this.visible = false;
  }

  *whenIReceiveFadeInGame() {
    this.vars.instance = "CLONE";
    yield* this.createCandles();
    this.vars.instance = "BASE";
  }

  *createCandles() {
    this.vars.x = 640;
    this.vars.y = -330;
    this.createClone();
    this.vars.x = 800;
    this.vars.y = -330;
    this.createClone();
    this.vars.x = 1120;
    this.vars.y = -330;
    this.createClone();
  }

  *startAsClone() {
    this.stage.vars.Clonecount++;
    while (true) {
      yield* this.wait(0.1);
      this.costumeNumber++;
      yield;
    }
  }

  *whenIReceiveGameStart() {
    if (this.toString(this.vars.instance) === "CLONE") {
      this.moveAhead();
      yield* this.position();
    }
  }

  *whenIReceivePositionObjects() {
    if (this.toString(this.vars.instance) === "CLONE") {
      yield* this.position();
    }
  }

  *position() {
    this.goto(
      this.toNumber(this.vars.x) - this.toNumber(this.stage.vars.Scrollx),
      this.toNumber(this.vars.y) - this.toNumber(this.stage.vars.Scrolly)
    );
    if (
      this.compare(
        this.x,
        this.toNumber(this.vars.x) - this.toNumber(this.stage.vars.Scrollx)
      ) === 0 &&
      this.compare(
        this.y,
        this.toNumber(this.vars.y) - this.toNumber(this.stage.vars.Scrolly)
      ) === 0
    ) {
      this.visible = true;
    } else {
      this.visible = false;
    }
  }

  *whenIReceiveImpact() {
    yield* this.wobble();
  }

  *wobble() {
    this.x += 2;
    this.y -= 2;
    yield* this.wait(0.04);
    this.x -= 6;
    yield* this.wait(0.04);
    this.x += 2;
    this.y += 2;
    yield* this.wait(0.04);
    this.goto(
      this.toNumber(this.vars.x) - this.toNumber(this.stage.vars.Scrollx),
      this.toNumber(this.vars.y) - this.toNumber(this.stage.vars.Scrolly)
    );
  }

  *whenIReceiveClearEverything() {
    /* TODO: Implement stop other scripts in sprite */ null;
    this.visible = false;
    if (!(this.toString(this.vars.instance) === "BASE")) {
      this.stage.vars.Clonecount--;
      this.deleteThisClone();
    }
  }
}
