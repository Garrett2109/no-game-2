/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Fly extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Fly1", "./Fly/costumes/Fly1.svg", { x: 25, y: 16 }),
      new Costume("Fly2", "./Fly/costumes/Fly2.svg", { x: 21, y: 7 }),
      new Costume("Fly3", "./Fly/costumes/Fly3.svg", { x: 12, y: 7 }),
      new Costume("Fly4", "./Fly/costumes/Fly4.svg", { x: 21, y: 7 }),
      new Costume("Carry1", "./Fly/costumes/Carry1.svg", { x: 25, y: 16 }),
      new Costume("Carry2", "./Fly/costumes/Carry2.svg", { x: 21, y: 7 }),
      new Costume("Carry3", "./Fly/costumes/Carry3.svg", {
        x: 15.128290000000021,
        y: 7,
      }),
      new Costume("Carry4", "./Fly/costumes/Carry4.svg", { x: 21, y: 7 }),
    ];

    this.sounds = [
      new Sound("Buzz", "./Fly/sounds/Buzz.mp3"),
      new Sound("Screech", "./Fly/sounds/Screech.mp3"),
    ];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "GAME START" },
        this.whenIReceiveGameStart
      ),
      new Trigger(Trigger.CLONE_START, this.startAsClone),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Position Objects" },
        this.whenIReceivePositionObjects
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "CLEAR EVERYTHING" },
        this.whenIReceiveClearEverything
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Delete Flies" },
        this.whenIReceiveDeleteFlies
      ),
    ];

    this.vars.instance = "BASE";
    this.vars.x = 0;
    this.vars.y = 0;
    this.vars.dx = 0;
    this.vars.dy = 0;
    this.vars.animFrame = 0;
    this.vars.costumeStub = 0;
    this.vars.edgespawn = "FALSE";
  }

  *whenGreenFlagClicked() {
    this.vars.instance = "BASE";
    this.size = 75;
    this.visible = false;
  }

  *whenIReceiveGameStart() {
    while (
      !(
        this.compare(this.stage.vars.Progress, 0) > 0 &&
        this.toNumber(this.stage.vars.Scrollx) === 0
      )
    ) {
      yield;
    }
    this.stage.vars.FliesToSpawn = 10;
    this.stage.vars.FliesToKill = 10;
    this.vars.edgespawn = "FALSE";
    this.stage.vars.SpawnedCarry = "FALSE";
    yield* this.createFlies(5);
  }

  *createFlies(num) {
    for (let i = 0; i < this.toNumber(num); i++) {
      this.createClone();
    }
  }

  *startAsClone() {
    this.vars.instance = "CLONE";
    this.stage.vars.Clonecount++;
    this.vars.costumeStub = "Fly";
    this.vars.animFrame = 1;
    this.stage.vars.FliesToSpawn--;
    this.goto(240 * (this.random(0, 1) * 2 - 1), this.random(-20, 100));
    if (this.toString(this.vars.edgespawn) === "FALSE") {
      this.x = this.random(-240, 240);
    }
    this.effects.color = this.random(0, 5) * 20;
    if (this.compare(this.stage.vars.FliesToSpawn, 0) < 0) {
      if (this.toString(this.stage.vars.SpawnedCarry) === "FALSE") {
        this.stage.vars.SpawnedCarry = "TRUE";
        this.stage.vars.Progress++;
        this.vars.costumeStub = "Carry";
        this.goto(-240, 100);
        this.effects.clear();
      }
    }
    if (this.compare(this.x, 0) < 0) {
      this.vars.dx = 1;
    } else {
      this.vars.dx = -1;
    }
    this.direction = 90 * this.toNumber(this.vars.dx);
    this.vars.dx = this.toNumber(this.vars.dx) * this.random(3, 6);
    this.vars.dy = this.random(-1, 1);
    this.vars.x = this.x;
    this.vars.y = this.y;
    yield* this.position();
    while (true) {
      this.moveAhead();
      if (this.toNumber(this.stage.vars.Scrollx) === 0) {
        this.vars.x += this.toNumber(this.vars.dx);
        if (this.compare(Math.abs(this.toNumber(this.vars.x)), 240) > 0) {
          this.vars.x =
            (this.toNumber(this.vars.x) /
              Math.abs(this.toNumber(this.vars.x))) *
            -240;
        }
        this.vars.y += this.toNumber(this.vars.dy) * 3;
        if (this.compare(this.vars.y, -30) < 0) {
          this.vars.y = -30;
          this.vars.dy = this.toNumber(this.vars.dy) * -1;
        } else {
          if (this.compare(this.vars.y, 120) > 0) {
            this.vars.y = 120;
            this.vars.dy = this.toNumber(this.vars.dy) * -1;
          }
        }
        if (this.random(1, 10) === 1) {
          this.vars.dy = this.random(-1, 1);
          this.vars.dx =
            (Math.abs(this.toNumber(this.vars.dx)) /
              this.toNumber(this.vars.dx)) *
            this.random(3, 6);
          if (this.random(1, 3) === 1) {
            this.audioEffects.volume = this.random(50, 100);
            this.audioEffects.pitch = this.random(0, 25);
            yield* this.startSound("Buzz");
          }
        }
        yield* this.position();
        yield* this.checkTongue();
        this.vars.animFrame = (this.toNumber(this.vars.animFrame) % 4) + 1;
        this.costume =
          this.toString(this.vars.costumeStub) +
          this.toString(this.vars.animFrame);
        yield* this.wait(0);
      } else {
        this.visible = false;
      }
      yield;
    }
  }

  *position() {
    this.goto(
      this.toNumber(this.vars.x) - this.toNumber(this.stage.vars.Scrollx),
      this.toNumber(this.vars.y) - this.toNumber(this.stage.vars.Scrolly)
    );
    if (
      this.compare(
        this.x,
        this.toNumber(this.vars.x) - this.toNumber(this.stage.vars.Scrollx)
      ) === 0 &&
      this.compare(
        this.y,
        this.toNumber(this.vars.y) - this.toNumber(this.stage.vars.Scrolly)
      ) === 0
    ) {
      this.visible = true;
    } else {
      this.visible = false;
    }
  }

  *whenIReceivePositionObjects() {
    if (this.toString(this.vars.instance) === "CLONE") {
      yield* this.position();
    }
  }

  *whenIReceiveClearEverything() {
    /* TODO: Implement stop other scripts in sprite */ null;
    if (this.toString(this.vars.instance) === "CLONE") {
      this.stage.vars.Clonecount--;
      this.deleteThisClone();
    }
  }

  *whenIReceiveDeleteFlies() {
    if (this.toString(this.vars.instance) === "CLONE") {
      this.stage.vars.Clonecount--;
      this.deleteThisClone();
    }
  }

  *checkTongue() {
    if (this.touching(this.sprites["Tongue"].andClones())) {
      this.audioEffects.pitch = 0;
      yield* this.startSound("Screech");
      this.stage.vars.FliesToKill--;
      if (!(this.sprites["Tongue"].costumeNumber === 1)) {
        this.stage.vars.RetractTongue = "true";
      }
      this.vars.edgespawn = "TRUE";
      if (
        this.compare(this.stage.vars.FliesToSpawn, 0) > 0 ||
        this.toNumber(this.stage.vars.FliesToKill) === 0
      ) {
        this.createClone();
      }
      if (this.toString(this.vars.costumeStub) === "Carry") {
        this.stage.vars.Progress++;
        this.stage.vars.letterx.push(this.x);
        this.stage.vars.lettery.push(this.y);
        this.stage.vars.lettertype.push("Z");
        this.broadcast("Spawn Letters");
      }
      this.stage.vars.sparksx.push(this.x);
      this.stage.vars.sparksy.push(this.y);
      this.stage.vars.sparkstype.push("spark");
      this.stage.vars.Clonecount--;
      this.deleteThisClone();
    }
  }
}
