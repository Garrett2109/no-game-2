/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Settings extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Block", "./Settings/costumes/Block.png", { x: 51, y: 51 }),
      new Costume("settings", "./Settings/costumes/settings.svg", {
        x: 38.25,
        y: 37.5,
      }),
      new Costume("Big", "./Settings/costumes/Big.svg", {
        x: 99.5514966579482,
        y: 99.64276373147338,
      }),
    ];

    this.sounds = [
      new Sound("Achievement", "./Settings/sounds/Achievement.mp3"),
      new Sound("PickUp", "./Settings/sounds/PickUp.mp3"),
      new Sound("Smash", "./Settings/sounds/Smash.mp3"),
    ];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.BROADCAST, { name: "Setup" }, this.whenIReceiveSetup),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Position Objects" },
        this.whenIReceivePositionObjects
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Impact" },
        this.whenIReceiveImpact
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "CLEAR EVERYTHING" },
        this.whenIReceiveClearEverything
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "GAME START" },
        this.whenIReceiveGameStart
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Hide Settings" },
        this.whenIReceiveHideSettings
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Drop Speaker" },
        this.whenIReceiveDropSpeaker
      ),
    ];

    this.vars.x = 265;
    this.vars.y = -150;
    this.vars.falling = "FALSE";
    this.vars.yvel = -26;
    this.vars.xvel = 0;
    this.vars.savecostume = "Block";
  }

  *whenGreenFlagClicked() {
    this.goto(-215, -150);
    this.size = 75;
    this.visible = false;
  }

  *whenIReceiveSetup() {
    this.vars.x = 265;
    this.vars.y = 200;
    this.stage.vars.Showingsettings = "FALSE";
    this.vars.falling = "FALSE";
    this.costume = "Block";
    this.moveAhead();
    yield* this.position();
    this.visible = true;
  }

  *position() {
    this.vars.savecostume = this.costume.name;
    this.costume = "Big";
    this.size = 400;
    this.goto(
      this.toNumber(this.vars.x) - this.toNumber(this.stage.vars.Scrollx),
      this.toNumber(this.vars.y) - this.toNumber(this.stage.vars.Scrolly)
    );
    this.costume = this.vars.savecostume;
    this.size = 75;
    this.visible = true;
  }

  *whenIReceivePositionObjects() {
    yield* this.position();
  }

  *wobble() {
    this.vars.savecostume = this.costume.name;
    this.costume = "Big";
    this.x += 2;
    this.y -= 2;
    this.costume = this.vars.savecostume;
    yield* this.wait(0.04);
    this.costume = "Big";
    this.x -= 6;
    this.costume = this.vars.savecostume;
    yield* this.wait(0.04);
    this.costume = "Big";
    this.x += 2;
    this.y += 2;
    this.costume = this.vars.savecostume;
    yield* this.wait(0.04);
    this.costume = "Big";
    this.goto(
      this.toNumber(this.vars.x) - this.toNumber(this.stage.vars.Scrollx),
      this.toNumber(this.vars.y) - this.toNumber(this.stage.vars.Scrolly)
    );
    this.costume = this.vars.savecostume;
  }

  *whenIReceiveImpact() {
    yield* this.wobble();
  }

  *whenIReceiveClearEverything() {
    /* TODO: Implement stop other scripts in sprite */ null;
    this.visible = false;
  }

  *whenIReceiveGameStart() {
    while (!(this.toNumber(this.stage.vars.Progress) === 8)) {
      yield;
    }
    while (true) {
      if (
        this.touching("mouse") &&
        this.toString(this.stage.vars.Clickguard) === "FALSE"
      ) {
        this.size = 80;
        if (this.mouse.down) {
          while (!!(this.mouse.down && this.touching("mouse"))) {
            yield;
          }
          if (this.touching("mouse")) {
            if (this.toString(this.stage.vars.Showingsettings) === "FALSE") {
              this.stage.vars.Showingsettings = "TRUE";
              yield* this.startSound("PickUp");
              this.broadcast("Render Settings");
            } else {
              this.stage.vars.Showingsettings = "FALSE";
              yield* this.startSound("PickUp");
              this.broadcast("Hide Settings");
            }
          }
        }
      } else {
        this.size = 75;
      }
      yield;
    }
  }

  *whenIReceiveHideSettings() {
    this.stage.vars.Showingsettings = "false";
  }

  *whenIReceiveDropSpeaker() {
    this.moveAhead();
    this.vars.y -= 2;
    yield* this.position();
    if (this.toNumber(this.stage.vars.Progress) === 7) {
      yield* this.broadcastAndWait("Click Guard On");
      yield* this.dropSpeaker();
      this.broadcast("Click Guard Off");
    }
  }

  *dropSpeaker() {
    this.vars.yvel = -1;
    this.vars.xvel = 0;
    this.vars.falling = "TRUE";
    while (!(this.compare(this.y, -149) < 0)) {
      this.vars.yvel--;
      this.vars.xvel = this.toNumber(this.vars.xvel) * 0.9;
      this.x += this.toNumber(this.vars.xvel);
      yield* this.fallAndCheck();
      yield;
    }
    yield* this.startSound("Smash");
    this.vars.x = this.x + this.toNumber(this.stage.vars.Scrollx);
    this.vars.y = this.y + this.toNumber(this.stage.vars.Scrolly);
    this.vars.falling = "FALSE";
    for (let i = 0; i < 4; i++) {
      this.effects.pixelate += 25;
      yield* this.wait(0.04);
      this.costume = "settings";
      yield;
    }
    for (let i = 0; i < 4; i++) {
      this.effects.pixelate -= 25;
      yield* this.wait(0.04);
      yield;
    }
    this.stage.vars.Progress++;
  }

  *fallAndCheck() {
    this.y += this.toNumber(this.vars.yvel);
    if (this.compare(this.y, -150) < 0) {
      this.y = -150;
    }
  }
}
