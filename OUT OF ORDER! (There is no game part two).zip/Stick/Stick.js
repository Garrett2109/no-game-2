/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Stick extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Stick1", "./Stick/costumes/Stick1.svg", {
        x: 39.092851733900034,
        y: 25.117550300400012,
      }),
      new Costume("Stick2", "./Stick/costumes/Stick2.svg", {
        x: 39.092854999999986,
        y: 25.117549999999994,
      }),
      new Costume("Stick3", "./Stick/costumes/Stick3.svg", {
        x: 39.092854999999986,
        y: 25.117549999999994,
      }),
      new Costume("Stick4", "./Stick/costumes/Stick4.svg", {
        x: 39.092854999999986,
        y: 25.117549999999994,
      }),
      new Costume("Alight1", "./Stick/costumes/Alight1.svg", {
        x: 39.125,
        y: 46.375,
      }),
      new Costume("Alight2", "./Stick/costumes/Alight2.svg", {
        x: 39.125,
        y: 42.375,
      }),
      new Costume("Alight3", "./Stick/costumes/Alight3.svg", {
        x: 39.125,
        y: 46.375,
      }),
      new Costume("Alight4", "./Stick/costumes/Alight4.svg", {
        x: 39.125,
        y: 42.375,
      }),
    ];

    this.sounds = [
      new Sound("PickUp", "./Stick/sounds/PickUp.mp3"),
      new Sound("Place", "./Stick/sounds/Place.mp3"),
      new Sound("Drop", "./Stick/sounds/Drop.mp3"),
      new Sound(
        "zapsplat_nature_fire_flames_torch_swoosh_003_89776",
        "./Stick/sounds/zapsplat_nature_fire_flames_torch_swoosh_003_89776.mp3"
      ),
    ];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.BROADCAST, { name: "Setup" }, this.whenIReceiveSetup),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Position Objects" },
        this.whenIReceivePositionObjects
      ),
      new Trigger(Trigger.CLICKED, this.whenthisspriteclicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "GAME START" },
        this.whenIReceiveGameStart
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "CLEAR EVERYTHING" },
        this.whenIReceiveClearEverything
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Check Stick Costume" },
        this.whenIReceiveCheckStickCostume
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Impact" },
        this.whenIReceiveImpact
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Drop Visible Objects" },
        this.whenIReceiveDropVisibleObjects
      ),
    ];

    this.vars.draggingSprite = "FALSE";
    this.vars.falling = "FALSE";
    this.vars.x = 86;
    this.vars.y = -75;
    this.vars.clickCount = 0;
    this.vars.lastx = 41;
    this.vars.lasty = -69;
    this.vars.xvel = 0;
    this.vars.yvel = -14;
    this.vars.sparks = "FALSE";
    this.vars.active = "FALSE";
    this.vars.alight = "FALSE";
    this.vars.costumeStub = "Stick";
    this.vars.costumeNo = 1;
    this.vars.touchingMaze = "false";
    this.vars.saveCostume = "Alight4";
    this.vars.stickdone = "FALSE";
    this.vars.holdOffsetx = 10;
    this.vars.holdOffsety = -12;
  }

  *whenGreenFlagClicked() {
    this.visible = false;
  }

  *whenIReceiveSetup() {
    this.direction = 90;
    this.vars.costumeStub = "Stick";
    this.vars.costumeNo = 1;
    this.vars.alight = "FALSE";
    this.vars.draggingSprite = "FALSE";
    this.vars.active = "FALSE";
    this.vars.falling = "FALSE";
    this.vars.stickdone = "FALSE";
    this.vars.x = 86;
    this.vars.y = -75;
    this.vars.clickCount = 0;
    this.costume = "Stick1";
    this.visible = false;
  }

  *whenIReceivePositionObjects() {
    if (this.toString(this.vars.stickdone) === "FALSE") {
      yield* this.position();
    }
  }

  *position() {
    if (this.toString(this.vars.draggingSprite) === "TRUE") {
      this.vars.x = this.x + this.toNumber(this.stage.vars.Scrollx);
      this.vars.y = this.y + this.toNumber(this.stage.vars.Scrolly);
    } else {
      this.size = 800;
      this.goto(
        this.toNumber(this.vars.x) - this.toNumber(this.stage.vars.Scrollx),
        this.toNumber(this.vars.y) - this.toNumber(this.stage.vars.Scrolly)
      );
      this.size = 100;
      this.visible = true;
    }
  }

  *whenthisspriteclicked() {
    if (this.compare(this.vars.clickCount, 6) < 0) {
      yield* this.startSound("PickUp");
      this.vars.clickCount++;
      this.stage.vars.sparksx.push(this.mouse.x);
      this.stage.vars.sparksy.push(this.mouse.y);
      this.stage.vars.sparkstype.push("wood");
      if (this.toNumber(this.vars.clickCount) === 6) {
        yield* this.startSound("Place");
        this.vars.active = "TRUE";
        this.direction = 90;
        this.vars.xvel = 0;
        this.vars.yvel = 4;
        yield* this.dropStick("TRUE");
      } else {
        yield* this.wobble(2, -2);
        yield* this.wobble(-6, 0);
        yield* this.wobble(2, 2);
        yield* this.resetwobble();
      }
    } else {
      yield* this.startSound("PickUp");
    }
  }

  *whenIReceiveGameStart() {
    while (!(this.toString(this.vars.active) === "TRUE")) {
      yield;
    }
    this.broadcast("Check Stick Costume");
    while (!(this.toString(this.vars.stickdone) === "TRUE")) {
      while (
        !(
          this.mouse.down &&
          this.touching("mouse") &&
          this.toString(this.stage.vars.Dragging) === "FALSE" &&
          this.toString(this.stage.vars.Showingsettings) === "FALSE" &&
          this.toString(this.stage.vars.Clickguard) === "FALSE"
        )
      ) {
        yield;
      }
      yield* this.dragAndDrop();
      yield;
    }
  }

  *dragAndDrop() {
    this.vars.draggingSprite = "TRUE";
    this.stage.vars.Dragging = "TRUE";
    this.vars.touchingMaze = "false";
    this.vars.holdOffsetx = this.x - this.mouse.x;
    this.vars.holdOffsety = this.y - this.mouse.y;
    this.vars.lastx = this.x;
    this.vars.lasty = this.y;
    this.goto(
      this.mouse.x + this.toNumber(this.vars.holdOffsetx),
      this.mouse.y + this.toNumber(this.vars.holdOffsety)
    );
    this.moveAhead();
    yield* this.checkTouchingMaze();
    if (this.toString(this.vars.touchingMaze) === "true") {
      this.goto(this.toNumber(this.vars.lastx), this.toNumber(this.vars.lasty));
      this.vars.xvel = 0;
      this.vars.yvel = 0;
      this.vars.draggingSprite = "false";
      this.stage.vars.Dragging = "false";
    } else {
      while (
        !(!this.mouse.down || this.toString(this.vars.touchingMaze) === "true")
      ) {
        this.vars.lastx = this.x;
        this.vars.lasty = this.y;
        this.goto(
          this.mouse.x + this.toNumber(this.vars.holdOffsetx),
          this.mouse.y + this.toNumber(this.vars.holdOffsety)
        );
        this.moveAhead();
        if (this.compare(Math.abs(this.x), 215) > 0) {
          this.x = (this.x / Math.abs(this.x)) * 215;
        }
        if (this.compare(Math.abs(this.y), 170) > 0) {
          this.y = (this.y / Math.abs(this.y)) * 170;
        }
        if (this.touching(this.sprites["Ground"].andClones())) {
          yield* this.groundcheck(1);
        }
        yield* this.checkTouchingMaze();
        yield;
      }
      this.vars.xvel = this.x - this.toNumber(this.vars.lastx);
      this.vars.yvel = this.y - this.toNumber(this.vars.lasty);
      if (this.toString(this.vars.touchingMaze) === "true") {
        yield* this.startSound("Drop");
        this.goto(
          this.toNumber(this.vars.lastx),
          this.toNumber(this.vars.lasty)
        );
        this.vars.xvel = 0;
        this.vars.yvel = 0;
      }
      if (this.compare(Math.abs(this.toNumber(this.vars.xvel)), 10) > 0) {
        this.vars.xvel =
          (this.toNumber(this.vars.xvel) /
            Math.abs(this.toNumber(this.vars.xvel))) *
          5;
      }
      if (this.compare(Math.abs(this.toNumber(this.vars.yvel)), 10) > 0) {
        this.vars.yvel =
          (this.toNumber(this.vars.yvel) /
            Math.abs(this.toNumber(this.vars.yvel))) *
          5;
      }
      this.vars.draggingSprite = "FALSE";
      this.stage.vars.Dragging = "FALSE";
      if (this.toString(this.stage.vars.Scrolling) === "true") {
        yield* this.sideCheck();
        this.vars.x = this.x + this.toNumber(this.stage.vars.Scrollx);
        this.vars.y = this.y + this.toNumber(this.stage.vars.Scrolly);
        while (!(this.toString(this.stage.vars.Scrolling) === "FALSE")) {
          yield;
        }
      }
    }
    yield* this.dropStick("TRUE");
  }

  *dropStick(sparks) {
    this.vars.sparks = sparks;
    this.vars.falling = "TRUE";
    this.vars.touchingMaze = "false";
    while (
      !(
        this.compare(this.y, -169) < 0 ||
        this.touching(this.sprites["Ground"].andClones()) ||
        this.toString(this.vars.touchingMaze) === "true"
      )
    ) {
      this.vars.yvel--;
      this.vars.xvel = this.toNumber(this.vars.xvel) * 0.9;
      this.x += this.toNumber(this.vars.xvel);
      yield* this.checkTouchingMaze();
      if (this.toString(this.vars.touchingMaze) === "true") {
        this.x += 0 - this.toNumber(this.vars.xvel);
        this.vars.xvel = 0;
        this.vars.touchingMaze = "false";
      }
      yield* this.fallAndCheck();
      yield* this.checkTouchingMaze();
      this.vars.x = this.x + this.toNumber(this.stage.vars.Scrollx);
      this.vars.y = this.y + this.toNumber(this.stage.vars.Scrolly);
      yield;
    }
    if (this.compare(this.vars.yvel, 0) > 0) {
      this.vars.yvel = 0;
      yield* this.groundcheck(-1);
      yield* this.dropStick(sparks);
    } else {
      yield* this.groundcheck(1);
    }
    if (this.compare(this.vars.yvel, -8) > 0) {
      this.vars.sparks = "FALSE";
    }
    this.vars.x = this.x + this.toNumber(this.stage.vars.Scrollx);
    this.vars.y = this.y + this.toNumber(this.stage.vars.Scrolly);
    if (this.toString(this.vars.sparks) === "TRUE") {
      yield* this.startSound("Drop");
      this.stage.vars.sparksx.push(this.x);
      this.stage.vars.sparksy.push(this.y);
      this.stage.vars.sparkstype.push("spark");
      this.vars.sparks = "FALSE";
      this.broadcast("Impact");
    }
    this.vars.falling = "FALSE";
  }

  *fallAndCheck() {
    this.vars.saveCostume = this.costume.name;
    this.costume = "Stick1";
    if (this.touching("edge")) {
      this.x += 0 - this.toNumber(this.vars.xvel);
    }
    this.y += this.toNumber(this.vars.yvel);
    if (this.compare(this.y, -170) < 0) {
      this.y = -170;
    }
    this.costume = this.vars.saveCostume;
  }

  *wobble(x, y) {
    this.size = 800;
    this.x += this.toNumber(x);
    this.y += this.toNumber(y);
    this.size = 100;
    yield* this.wait(0.04);
  }

  *whenIReceiveClearEverything() {
    /* TODO: Implement stop other scripts in sprite */ null;
    this.visible = false;
  }

  *groundcheck(dir) {
    this.vars.saveCostume = this.costume.name;
    this.costume = "Stick1";
    if (
      this.touching(this.sprites["Ground"].andClones()) ||
      this.touching(this.sprites["Maze"].andClones())
    ) {
      while (
        !(
          !(
            this.touching(this.sprites["Ground"].andClones()) ||
            this.touching(this.sprites["Maze"].andClones())
          ) || this.touching("edge")
        )
      ) {
        this.y += 1 * this.toNumber(dir);
      }
      if (this.touching(this.sprites["Maze"].andClones())) {
        this.warp(this.position)();
      }
    }
    this.costume = this.vars.saveCostume;
  }

  *sideCheck() {
    this.vars.saveCostume = this.costume.name;
    this.costume = "Stick1";
    if (this.touching(this.sprites["Maze"].andClones())) {
      while (!!this.touching(this.sprites["Maze"].andClones())) {
        this.x += 1;
      }
    }
    this.costume = this.vars.saveCostume;
  }

  *whenIReceiveCheckStickCostume() {
    while (true) {
      if (this.toString(this.vars.alight) === "false") {
        if (this.touching(this.sprites["Pixelfire"].andClones())) {
          yield* this.startSound(
            "zapsplat_nature_fire_flames_torch_swoosh_003_89776"
          );
          this.vars.alight = "true";
          this.vars.costumeStub = "Alight";
        }
      } else {
        if (
          this.touching(this.sprites["Water"].andClones()) ||
          this.touching(this.sprites["Puddle"].andClones())
        ) {
          this.vars.alight = "false";
          this.vars.costumeStub = "Stick";
        }
        if (
          this.touching(this.sprites["Barrel"].andClones()) &&
          this.toString(this.stage.vars.Scrolling) === "FALSE"
        ) {
          this.stage.vars.Dragging = "false";
          this.vars.draggingSprite = "false";
          this.vars.stickdone = "TRUE";
          this.visible = false;
          this.broadcast("Hexplosion");
          /* TODO: Implement stop other scripts in sprite */ null;
          return;
        }
      }
      this.vars.costumeNo = (this.toNumber(this.vars.costumeNo) % 4) + 1;
      this.costume =
        this.toString(this.vars.costumeStub) +
        this.toString(this.vars.costumeNo);
      yield* this.wait(0.1);
      yield;
    }
  }

  *checkTouchingMaze() {
    this.vars.saveCostume = this.costume.name;
    this.costume = "Stick1";
    if (this.touching(this.sprites["Maze"].andClones())) {
      this.vars.touchingMaze = "true";
    }
    this.costume = this.vars.saveCostume;
  }

  *whenIReceiveImpact() {
    if (this.toString(this.vars.falling) === "FALSE") {
      yield* this.wobble(2, -2);
      yield* this.wobble(-6, 0);
      yield* this.wobble(2, 2);
      yield* this.resetwobble();
    }
  }

  *resetwobble() {
    this.size = 800;
    this.goto(
      this.toNumber(this.vars.x) - this.toNumber(this.stage.vars.Scrollx),
      this.toNumber(this.vars.y) - this.toNumber(this.stage.vars.Scrolly)
    );
    this.size = 100;
  }

  *whenIReceiveDropVisibleObjects() {
    if (this.toString(this.vars.active) === "TRUE") {
      if (this.toString(this.vars.draggingSprite) === "FALSE") {
        if (
          this.compare(
            Math.abs(
              this.toNumber(this.vars.x) -
                this.toNumber(this.stage.vars.Scrollx)
            ),
            240
          ) < 0 &&
          this.compare(
            Math.abs(
              this.toNumber(this.vars.y) -
                this.toNumber(this.stage.vars.Scrolly)
            ),
            180
          ) < 0
        ) {
          yield* this.dropStick("FALSE");
        }
      }
    }
  }
}
