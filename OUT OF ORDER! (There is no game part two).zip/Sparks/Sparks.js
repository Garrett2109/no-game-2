/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Sparks extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("spark", "./Sparks/costumes/spark.svg", {
        x: 0.7222222222222001,
        y: 0.8888888888888857,
      }),
      new Costume("wood1", "./Sparks/costumes/wood1.svg", {
        x: 0.722219999999993,
        y: 0.8888900000000035,
      }),
      new Costume("wood2", "./Sparks/costumes/wood2.svg", {
        x: 0.784719999999993,
        y: 0.8888900000000035,
      }),
      new Costume("wood3", "./Sparks/costumes/wood3.svg", {
        x: 0.784719999999993,
        y: 0.8888900000000035,
      }),
      new Costume("leaf", "./Sparks/costumes/leaf.svg", {
        x: 0.722219999999993,
        y: 0.8888900000000035,
      }),
    ];

    this.sounds = [];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.CLONE_START, this.startAsClone),
      new Trigger(Trigger.BROADCAST, { name: "Setup" }, this.whenIReceiveSetup),
      new Trigger(
        Trigger.BROADCAST,
        { name: "GAME START" },
        this.whenIReceiveGameStart
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "CLEAR EVERYTHING" },
        this.whenIReceiveClearEverything
      ),
    ];

    this.vars.instance = "SPAWNER";
    this.vars.xvel = 0.24315330918113873;
    this.vars.yvel = -20;
    this.vars.costume = "spark";
    this.vars.sparkNumber = 10;
  }

  *whenGreenFlagClicked() {
    this.vars.instance = "BASE";
    this.moveAhead();
    this.visible = false;
  }

  *startAsClone() {
    if (this.toString(this.vars.instance) === "SPAWNER") {
      this.vars.instance = "CLONE";
      if (this.toString(this.vars.costume) === "leaf") {
        yield* this.instaclone();
      } else {
        for (let i = 0; i < this.toNumber(this.vars.sparkNumber); i++) {
          this.createClone();
          yield;
        }
      }
    }
    this.stage.vars.Clonecount++;
    this.costume = "spark";
    this.effects.brightness = this.random(50, 100);
    this.effects.ghost = this.random(0, 20);
    this.size = 200;
    if (this.toString(this.vars.costume) === "wood") {
      this.costume = "wood" + this.toString(this.random(1, 3));
      this.effects.brightness =
        (this.random(0, 1) * 2 - 1) * this.random(10, 20);
      this.effects.ghost = 0;
      this.size = 300;
    }
    if (this.toString(this.vars.costume) === "leaf") {
      this.costume = "leaf";
      this.effects.brightness =
        (this.random(0, 1) * 2 - 1) * this.random(10, 20);
      this.effects.ghost = 0;
      this.size = 300;
    }
    this.moveBehind(1);
    this.visible = true;
    this.vars.xvel = this.random(2, 5) * (this.random(0, 1) * 2 - 1);
    if (this.toString(this.stage.vars.Downsparks) === "TRUE") {
      this.vars.yvel = 0;
    } else {
      this.vars.yvel = this.random(2, 6);
      this.moveAhead();
    }
    for (let i = 0; i < 20; i++) {
      this.effects.ghost += 5;
      this.vars.yvel--;
      this.vars.xvel = this.toNumber(this.vars.xvel) * 0.9;
      this.x += this.toNumber(this.vars.xvel);
      this.y += this.toNumber(this.vars.yvel);
      if (
        this.compare(this.y, -177) < 0 ||
        this.touching(this.sprites["Ground"].andClones())
      ) {
        this.stage.vars.Clonecount--;
        this.deleteThisClone();
      }
      yield;
    }
    this.stage.vars.Clonecount--;
    this.deleteThisClone();
  }

  *cloneSparks() {
    while (!(this.stage.vars.sparkstype.length === 0)) {
      this.goto(
        this.toNumber(this.itemOf(this.stage.vars.sparksx, 0)),
        this.toNumber(this.itemOf(this.stage.vars.sparksy, 0))
      );
      this.vars.costume = this.itemOf(this.stage.vars.sparkstype, 0);
      this.stage.vars.sparksx.splice(0, 1);
      this.stage.vars.sparksy.splice(0, 1);
      this.stage.vars.sparkstype.splice(0, 1);
      this.vars.instance = "SPAWNER";
      this.vars.sparkNumber = 10;
      if (this.toString(this.vars.costume) === "leaf") {
        this.vars.sparkNumber = 20;
      }
      this.createClone();
    }
  }

  *whenIReceiveSetup() {
    this.stage.vars.Downsparks = "FALSE";
    this.stage.vars.sparksx = [];
    this.stage.vars.sparksy = [];
    this.stage.vars.sparkstype = [];
  }

  *whenIReceiveGameStart() {
    while (true) {
      while (!(this.compare(this.stage.vars.sparkstype.length, 0) > 0)) {
        yield;
      }
      yield* this.cloneSparks();
      yield;
    }
  }

  *instaclone() {
    for (let i = 0; i < this.toNumber(this.vars.sparkNumber); i++) {
      this.createClone();
    }
  }

  *whenIReceiveClearEverything() {
    /* TODO: Implement stop other scripts in sprite */ null;
  }
}
